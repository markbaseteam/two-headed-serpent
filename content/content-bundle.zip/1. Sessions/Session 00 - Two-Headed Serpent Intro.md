---
sessiondate: 2021-08-09
sessionyear: 2021
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: Character creation.
---
# Session 00 - Character Creation
**Date:** 2021-08-09

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Max Tannenbaum]]
- [[Paul Schreiber]]

## Events
Just character creation

##### Navigation
[[Two-Headed Serpent]] | [[Session 01 - Bolivia]]

