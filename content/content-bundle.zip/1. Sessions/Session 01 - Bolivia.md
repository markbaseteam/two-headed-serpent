---
sessiondate: 2021-09-20
sessionyear: 2021
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 01 - Bolivia
**Date:** 2021-09-20

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Max Tannenbaum]]
- [[Paul Schreiber]]

## Events
March 15, 1933.

Aid mission to Bolivia under the aspices of the [[Caduceus]] Foundation. Bolivia in war with Paraguary over contested ground. [[Dr. Arturo Ursini]] is leading us (a CF guys). There are nurses!

Dr. tries to spills beans about [[Caduceus]]. Gets murdered! Its an ambush by German Bolvians! [[Amandus Winston Steel|Amandus]] shoots one and hits to cover. They start to come forward. Explode another one with the second barrel and move to another cover (damn Kaiser Lovers)

This guy shoots (misses), then closes with a machete (or Ma-cheet as Amanda called it). He smells bad and his eyes are glassed over. Thorns are embedded in his arms, and a dirty leg wound. Sauer Krauts....

Captain pulls out something glittery - a spike. And throws it and hits one of his own men. And it electrocutes the man.

Quickly reload and blast the guy in front of me, move forward into different covered. We all take parting shots at the Captain. He takes damage, but gets away.

Spike - delicately engraved (scales). Shaped like a tail of a serpent. Patterns on the "belly" that looks like writing (Cthulhu mythos). [[Paul Schreiber|Paul]] seems disturbed by this writting. [[Serpent Race]].

[[Max Tannenbaum|Max]] "reads" the soldier. They love their captain, but something weird starting acting weird. People stopped responding - lost contact. His leader went away for a bit, came back, and hyptnotized them. Then everything is in a haze.

We check [[Dr. Arturo Ursini|Arturo's]] pack and pack animals. We find a map and two letters

![[bolivian_forest_region.jpg]]

[[Bolivia Briefing]]

[[Bolivia Gomez Letter]]

Retrieve mummy!

- Other loot 
	- On [[Dr. Arturo Ursini|Arturo's]] body:
		- Antivenom for snackbites – multiple pouches
		- luck roll to determine whether or not the correct type of antivenom is present
		- Bloodstained folder with two letters & map in it
	- On Mule:
		- Extra radio
		- Leather Suitcase containing:
		- clothes & toiletries
		- 3 sticks of dynamite
		- .45 revolver
		- ammunition

Tea Time! And Nachos!

Glass on the road. About the size of standard paper, curved, thick as a AA battery. There is one, acting odd. [[Amandus Winston Steel|Amandus]] calls [[Paul Schreiber|Paul]] over to look at this glass. Its part of a [[Transport Sphere|spherical machine]]. Then...

Monkeys are laughing at us. [[Max Tannenbaum|Max]] engages with it. Its turns its palm to us, a [[Gold Bracelet|glint of gold]]. Flame erupts out! Max shoots it. Wrapped around its arm is another spike.

Spike magic. First electricity, now fire. Red eyes. And it moves...

[[Max Tannenbaum|Max]], on the gold fire serpent bracelet:

>I'm going to take it off the monkey, look at it curiously, and hand it to you to go with the spike. You seem to know this stuff. I mostly just think that if it's going to attach itself to someone possibly against their will, it'd probably be me first.


Back to the sphere - off to the east. Large enough to contain 1-2 person. Its been here about 3 days. Crashed on the 12th of March. Lines up with when people lost emotions. ([[Amandus Winston Steel|Amandus]] Extreme Natural World). Little over a week ago other soldiers went missing (both sides).

There is thick, dry fluid inside. [[Joseph Laird|Joseph]] every sus of [[Max Tannenbaum|Max]].

Perhaps [[Caduceus]] Foundation is involved in the bizarre and profound. [[Max Tannenbaum|Max]] confesses his evil powers.

[[Amandus Winston Steel|Amandus]] - you know, they are not really Germans...

##### Navigation
[[Session 00 - Two-Headed Serpent Intro]] | [[Two-Headed Serpent]] | [[Session 02 - Bolivia]]

