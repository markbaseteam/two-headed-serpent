---
sessiondate: 2021-10-04
sessionyear: 2021
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 02 - Bolivia
**Date:** 2021-10-04

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Max Tannenbaum]]
- [[Paul Schreiber]]

## Events
Meet [[Hugo Gustafsson|Hugo]]. Translator has a bad arm, he used to be in the Bolivian army but is not now. The fighting has (should have) moved on. He is also a scout (how he got the broken arm) and is sweet on the camp nurse. He has been around 3 weeks. One area was near a recent battle - it was clear no one survived the battle. Then locals went there and never came back.

### Up the Hill
We do find a panel and remnants of the glass sphere. We play the new toy. [[Hugo Gustafsson|Hugo]] gets it powered up and it seems to tap into his brain for information (directions, instructions). Then it freaks out that it cannot find the Bubble

### To The Aid Camp
We are welcome to the smell of food. And a nurse. Weird - 2 Bolivian soldiers guarding some stone buildings off from the camp.

![[bolivia_aid_camp.jpg]]

The nurse ([[Alaina]]) is acting oddly, distracted. Reacted to [[Amandus Winston Steel|Amandus']] face but not the scars. And reacts to the soldiers for a moment before going distant again. She is pushing [[Dr. Gomez]]. Go to the hospital tent.

There has been something odd at the radio tent since [[Hugo Gustafsson|Hugo]] was last in camp (he helped set it up). Someone shot the radio

The soldiers look like they have old wounds - much like the bizarre ones we fought before.

[[Max Tannenbaum|Max]] is positive the nurse is abusing opiods. [[Amandus Winston Steel|Amandus]] - extreme charms her. The soldiers have these weird terrified dogs. Scales, fixes them. They are not human.

The soldiers have been terrorizing this camp and taking supplies. They have gone across the ford.

The locals do have a ceremon to a dreaming spirit. The cook will show us where there is a flower that [[Max Tannenbaum|Max]] could make a poison that likely only impacts lizards.

### Radio Caduceus
We move to a safer place, set up radio. Contact [[Caduceus]]. Somewhat lie about the situation. They bullshit that this was the plan and we can join the club. Charity missions cover for opportunity to deal with real threats of the darkness.

Ancient Race - the [[Serpent Race|Serpent people]] most peaceful, but the [[Inner Night]] is at war with humanity. The war may have opened/reveled a Temple with a mummy and artifacts that the Inner Night would want (as does [[Caduceus]]).

Bring the [[The Queen|Mummy]] Back ALIVE! The Sleeper. (the dreamer?)

The flower seems to be a dead end. But we do have dynamite and [[Joseph Laird|Joseph]] is an expert.

The Cook talks of the temple - its not something that can be seen, but its there and sacred. We will go with the cook to see the flowers because its likely linked to the temple/mummy. It’s near the battle site, where there are still bodies. Nasty smell.

We might search the battlefield for grenades. We rest.

##### Navigation
[[Session 01 - Bolivia]] | [[Two-Headed Serpent]] | [[Session 03 - Bolivia]]

