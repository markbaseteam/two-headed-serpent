---
sessiondate: 2021-10-18
sessionyear: 2021
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 03 - Bolivia
**Date:** 2021-10-18

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Max Tannenbaum]]
- [[Paul Schreiber]]

## Events
We camp. Near the AM, [[Amandus Winston Steel|Amandus]] hears something - Its one of those Lizard dogs. There is also a person about 75' back. Its one of the officers. There are also a not-normal troops. They likely passed over the ford to the battlefield which we get up.

[[Gilmar the Translator]] tells us a spanish word we hear on our side of the river - "orders are absolute silence, all of you"

There is NO natural / animal life here. Some of the bodies look to have battle wounds. But some form of whip and (tentacle) inflicted wounds as well - these were running away from the holes. In the back for the truck [[Hugo Gustafsson|Hugo]] finds duct tape, 8 sticks of dynamite, ball bearings, and 3 grenades

Other truck has 10 sticks and 4 grenades, and an anti-personal mine.

There has been some form of gooey drops form the hole - and something has walked out and back. [[Hugo Gustafsson|Hugo]] nearly falls down the hole...then something comes out. A mass.

[[Amandus Winston Steel|Amandus]], not really seeing what it is, tossed a grenade and hurts whatever it is - it wails. Bullets are not much help. [[Hugo Gustafsson|Hugo]] looks to drop a grenade and run. The stairs collapse - and we hear birds chirping!

Then we hear an explosion and a grinding sound. Based on more of the artwork [[Hugo Gustafsson|Hugo]] saw, it might be the center point. We decide if we go into the hole it might lead us to where we want to go. We rig a patch in the ramp down the hole.

1000 feet down.

Map that we piece together.

![[bolivia_ward_map.jpg]]

Takes awhile, but we get to a spiral temple in the middle.

Some of the soliders, officiers, and lizard in the area. [[Amandus Winston Steel|Amandus]] sneaks around and takes out three of the guards.

Getting bold, [[Amandus Winston Steel|Amandus]] goes for the Captain, who spends a bunch of Luck to see him. He turns and hisses at Amandus. A wall of force knocks him back. He manages to stay conscious. Then he pulls out some arcane whistle and it rings in our head.

The big lizard comes forward and [[Max Tannenbaum|Max]] screams, bringing it down on Max and [[Hugo Gustafsson|Hugo]].

[[Amandus Winston Steel|Amandus]] shoots the captain but somehow he does not die! He continues to command. Amandus dives for cover but is shot by the Sgt. [[Hugo Gustafsson|Hugo]] kills the Lizard.

[[Joseph Laird|Joseph]] comes streaking across the field and kills the Capt. Then, the other soldiers suddenly fell their injuries! The Sgt tries to flee but [[Amandus Winston Steel|Amandus]] guns him down.

Snakes still going to the temple.

We do try to help a few of the soldiers. They came here, then the officers just started talking and talking, then nothing.

Lunch!

##### Navigation
[[Session 02 - Bolivia]] | [[Two-Headed Serpent]] | [[Session 04 - Bolivia]]

