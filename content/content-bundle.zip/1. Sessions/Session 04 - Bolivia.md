---
sessiondate: 2021-11-01
sessionyear: 2021
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 04 - Bolivia
**Date:** 2021-11-01

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Max Tannenbaum]]
- [[Paul Schreiber]]

## Events
The non-poop temple - the ground has been disturbed as if this temple corkscrewed out of the ground. There are holes in the temple the snakes enter. The door is precisely engineered

The captain looks like he is wearing a human suit. He has a stone archaic whistle (cold) and a map/diagram.

![[bolivia_ward_map.jpg]]

Then sneaking under the underbrush - [[Black Ooze Creature|black ooze]]!

![[black_ooze_creature.jpg]]

And a few lizard dogs. The ooze tries to swallow [[Hugo Gustafsson|Hugo]], but luck is on his side and he avoids it. A lizard dogs after [[Amandus Winston Steel|Amandus]] but gets a face full of shotgun blast.

The ooze slimes its way up to [[Amandus Winston Steel|Amandus]]. But I learn something I did not want to know. A bit of madness ensues as he talks to his girlfriend, about her brother, who may not really be dead.

The ooze moves on as [[Amandus Winston Steel|Amandus]] continues his discussion. It grabs [[Paul Schreiber|Paul]] but is unable to swallow him. [[Joseph Laird|Joseph]] tries to blow up the ooze. Eyes and ooze everywhere (except Amandus)!

[[Amandus Winston Steel|Amandus]] comes back from this chat with his dead girlfriend [[Stephanie]]. We try to get the door open, playing with the various objects we have found. No dice, so we blow it open (but the lock is still intact).

##### Navigation
[[Session 03 - Bolivia]] | [[Two-Headed Serpent]] | [[Session 05 - Bolivia]]

