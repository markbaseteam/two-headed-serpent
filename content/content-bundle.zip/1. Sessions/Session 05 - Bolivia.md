---
sessiondate: 2021-11-16
sessionyear:  2021
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 05 - Bolivia
**Date:** 2021-11-16

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Max Tannenbaum]]
- [[Paul Schreiber]]

## Events
[[Amandus Winston Steel|Amandus]] takes the lead with a torch (flashlight) into the temple. Starts out plain, then bas relief, gold leaf. There are holes, and an occasional snake dropping out and on their own mission. The bas relief gets more complex as we descend. Snake motif, including crown of 6 snakes. Underground is sacred.

We do come to a part with a carpet 20’ of snakes. We can use the holes to go over them The holes (and snakes) stop. We continue on to a vast chamber! Archway with two twisting serpents that meet with one head.

The green eyed serpent head shoots out a green ray at [[Amandus Winston Steel|Amandus]]. Amandus shoots back “Animated statue snake with green eyes… of doom!” [[Paul Schreiber|Paul]] tries to show the snake bracelet to see if it will let us pass. The snake statue hits Paul. Burns his arm badly. And it paralyzes him. We pull him back out of the hallway. [[Hugo Gustafsson|Hugo]] provides provides first and and drains the pus out of the wound. There are now vivid green scales

[[Amandus Winston Steel|Amandus]] tries to give covering fire to let the group in. Takes a gut wound. Falls over paralyzed. They get to the other side and get the eyes out. I the room is a large female mummy.

[[Max Tannenbaum|Max]] helps [[Amandus Winston Steel|Amandus]], patches him up but he is a bit more serpentine (1 san point).

[[Paul Schreiber|Paul]] and [[Joseph Laird|Joseph]] go up to the spiral dias - but it is plastered over a massive giant coral snake! [[Amandus Winston Steel|Amandus]] is on the edge of sanity. Amandus does take a chunk out with the shotgun. We retreat to the hallway. It waits patiently.

[[Amandus Winston Steel|Amandus]] comes forward to toss a grenade….and gets swallowed whole! It also bites [[Hugo Gustafsson|Hugo]], but he shakes off the poison. Amandus starts to cut out from the inside.

[[Joseph Laird|Joseph]] is trying to rig explosive, and [[Hugo Gustafsson|Hugo]] volunteers to turn in and place it. Short timer setup. Joseph, hard success, dodges the snake. Hugo gets a perfect shot with the shotgun (max damage). The snake did not like it - tail slaps him massively.

Snake is killed as the bomb goes off, just as [[Amandus Winston Steel|Amandus]] emerges. He does an Indiana Jones and hides in the snake skull - gets smashed around but emerges (3 HP, no luck). [[Max Tannenbaum|Max]] helps him heal.

The throne and the mummy are fine.

##### Navigation
[[Session 04 - Bolivia]] | [[Two-Headed Serpent]] | [[Session 06 - Bolivia]]

