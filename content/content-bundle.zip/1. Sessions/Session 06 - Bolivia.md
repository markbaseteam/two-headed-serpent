---
sessiondate: 2021-12-13
sessionyear: 2021
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 06 - Bolivia
**Date:** 2021-12-13

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Max Tannenbaum]]
- [[Paul Schreiber]]

## Events
Investigate the throne - gold plated jade. We make a stretcher. As we grab, the mummy starts to fall and is basically hollow (much like shed snake skin). [[Paul Schreiber|Paul]] grabs the circlet. There is a dark hole where the seat of the throne was.

It drops about 50', and there is a chamber. [[Joseph Laird|Joseph]] drops down all mission impossible style. Table with the woman (breathing, asleep) is there, chest, murals (and that of the temple). Shafts. People bowing to the red robe serpent woman. Gold sceptre and crown (ruby eye, 6 heads). Joseph goes down and determines the chest is sealed (likely no air in or out).

We tried to get an transcript of the symbols and such. [[Max Tannenbaum|Max]] (Joel's PC) crit fails healing [[Amandus Winston Steel|Amandus]]....sigh. We study the murals - there was a civilization that was splitting amongst religion. Then a war with something, and their main tech base was taken from them. The temple is a gateway is a a dreamland to try to reach the technology. This person is the "[[The Queen|Dreamer]]". [[Naacal]] - the language. The sleeper was supposed to have awaken long ago. She is very slowly awaking.

Lift off the list the chest. There is a fine leather case with scrolls. Fine robes, and 3 carved wooden boxes.

One plain and flat - 12' long whip.

One looks like a hat box - hat - would be a for a [[Cobra Crown|crown]]

One looks is bigger. - Ornate [[Serpent Scepter|sceptre]] with a pearl the size of a fist on the end. Serpentine carved

[[Hugo Gustafsson|Hugo]] picks up the sceptre and tries it out. It feels live and has power. He invests himself, and it feels like it should be in his hand. Up top, [[Amandus Winston Steel|Amandus]] see a gallizon weird snakes show up. Hugo tries to climb up, but nearly kills himself. He gets up, the snake stay 8' away. We bring everything we can, including the stirring dreaming. The snakes follow.

We get out, surrounded by snakes. [[Hugo Gustafsson|Hugo]] tries to command them to leave. They leave! Radio [[Caduceus]] for extraction by airboat. Wrap up at the camp and back to New York.

Some additional pictures

![[sikorsky_s_40.jpg]]

![[arturo_shot.jpg]]

![[serpent_person_mummy.jpg]]

On the long trip, [[Paul Schreiber|Paul]] reads some of the Scroll. Sanity wanes.
##### Navigation
[[Session 05 - Bolivia]] | [[Two-Headed Serpent]] | [[Session 07 - New York]]

