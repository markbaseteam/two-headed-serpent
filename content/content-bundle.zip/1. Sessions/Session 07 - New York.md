---
sessiondate: 2021-12-27
sessionyear: 2021
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 07 - New York
**Date:** 2021-12-27

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Max Tannenbaum]]
- [[Paul Schreiber]]

## Events
So we left NY March 12. We are back March 24, 1933.

Are we keeping anything from [[Caduceus]]. We are fairly forthright with the them. [[Quentin Shapiro|Shapiro]] meets us at the airport late in the day. [[The Queen|Snake lady]] is more active but still unconscious. [[Joseph Laird|Joseph]] goes to his manor, a car for the rest of us, then a truck for the snake lady. There is also a 7' goon. Offer us [[Caduceus]] Rank Tier 2, and we get a key to the visitor lounge. Shapiro is a bit nervous about the goon. [[Canning]] is his name and is overseeing the unloading.

- [[Quentin Shapiro]], 36, Caduceus scientist and team handler.
- [[Canning]], [[Joshua Meadham|Joshua Meadham's]] Manservant and 7' goon.

[[Quentin Shapiro|Shapiro]] notes their might be leaks in the organization. More important, alcohol is not technically legal again yet (watered down beer is)

![[new_york.jpg]]

FDR first fireside chat was March 12. This is his the start of his first term. Hitler now in power. Protests new city hall, which is near [[Caduceus|Caduceus']] HQ.

### In NYC
#### [[Joseph Laird|Joseph]]
![[josephs_house.jpg]]

[[Thaddeus Laird|Joseph's brother's]] remains are not found. He was a member of [[Caduceus]].

In town apartment had an attempted break in.

Gave over the lock after studying it on the plane. Fully Mechanical.

#### [[Amandus Winston Steel|Amandus]]
![[churchill_prescription.jpg]]

![[speakeasy.jpg]]

Dropped off at the VA club. See a friend - [[Miles Miller]]. Miles got a job to do security at a [[Red Hook warehouse|warehouse]] - lots of jobs at Red Hook. He starts on Monday. Might be associated with [[Caduceus]]. They are looking for vets. Set up a coffee chat after he starts the job. Try to get some sanity back, but the talk of Caduceus throws him off - there is an odd bartender, very sus.

Brings back Capybara for the VA. "[[Capy]]"

#### [[Hugo Gustafsson|Hugo]]
Kept the [[Serpent Scepter]]. Back to his apartment. Putts around his shop. Fails his sanity recover roll too! Apartment manager is [[Meridith Jones]]. She lets him know that some people were around looking for him. Big and scary looking. This was during his trip. Broken nose, but not [[Canning]]. Too tight suit.

#### [[Paul Schreiber|Paul]]
Goes back to his apartment to try to make a some weird science device to of the [[Gold Bracelet|flame torch]].

### To the [[Caduceus Building]]
Up a secret elavator bay. It needs out key to work.

elevator: needs key to work - B, 7 & 8, 17

We meet with [[Quentin Shapiro|Shapiro]]. He gives us info

- Not just humans in the world
- [[Joshua Meadham]] was in big pharma, then resigned to start [[Caduceus]].
- They really need operatives.

We all sign on for more and get a packet.

![[caduceus_briefing.png]]

![[caduceus_overview.jpg]]

Reading the handouts losses 1d4 san (of course, lost 4). But learn a bit of [[Naacal]] (snake language) as well.

- [[Phillip Conners]] - Quartermaster. A bit overweight, balding, sweating, chain smoker.
- [[Francesca De Luca]] - Security chief. Near main entrance. Professional, pronounced widow's peak. She is more for the building. Our's is the type of team to investigate the break in attempt or the thug dropping by Hugo's

Other areas: 
- laboratories
- artifact storage room
- filing room
- reference library
- radio room.

**Overhear: North Borneo getting hot. Any teams available. We dub ourselves the A Team.**

##### Navigation
[[Session 06 - Bolivia]] | [[Two-Headed Serpent]] | [[Session 08 - New York to North Borneo]]

