---
sessiondate: 2022-01-10
sessionyear: 2022
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 08 - New York to North Borneo
**Date:** 2022-01-10

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Max Tannenbaum]]
- [[Paul Schreiber]]

## Events
[[Max Tannenbaum|Max]] (Joel) finally decides to show up :-). Mob flashback. Since this is a mob flashback, otherwise known as a flash mob….

![[caduceus_floors.jpg]]

- They offer up lab space for those that would like it
- Follow-up on [[Thaddeus Laird|Joseph's brother]].  He succumbed to the sleeping sickness - Belgian Congo
- Lab tour by the nerds. [[Joseph Laird|Joseph]] and [[Amandus Winston Steel|Amandus]] go to [[The Knox Club|Joseph's club]], which does have real alcohol
- There is a big cube they are working on in one of the labs. It analyzes viruses using Science. It uses Cthulhu power, otherwise known as Linux. [[Hugo Gustafsson|Hugo]] is just too in tune with it - sucks out some sanity and magic points. There is something in that machine…driving it.
- [[Max Tannenbaum|Max]] - Tuesday or Wednesday during the day I’m going to have a chat with my [[Max's Rabbi|Rabbi]] about the existence of nonhumans and their likely theological place in the world. Max, unlike me, will not wonder if lizard people are Kosher. They clearly aren’t. Clearly.
- Note - some of us seem to still have some scales.
- [[Amandus Winston Steel|Amandus]] meets up with [[Miles Miller]] - lots at the warehouse. There is [[Caduceus]] build attached to ware house. 24 people watching this place. No people, some crates in and out.

[[Francesca De Luca]] asks that we look into some of the threatening events of late. Impacting the secretarial pool.

- [[Delores Parville]] - [[Joshua Meadham|Meadham's]] secretary, has been watched - now security guard walks her home.
- [[Mabel Finley]] - asked questions and had neighbors ask question by a man that matches the description of the person asking about Hugo
- [[Almeda McBurney]] - Purse stolen by street urchin recently after thinking she’s been followed
- [[Selma Halberstam]] - entire flat was tossed, her journal and paperwork stolen
- [[Max Tannenbaum|Max]] - mob is interested - is [[Caduceus]] moving drugs instead of medicine?
- We do follow the women. There is a kid following. Seems to be with the local mob.
- Then we will need to meet up with [[Caduceus]] rep Friday as the situation has escalated.

We are off to North Borneo. While it seems to be Hepatitis, but it might be [[Yellow Death]] (something with the serpents - could be a bio-weapon) [[Quentin Shapiro|Shapiro]] is going since he can run a [[Viral Analyzer|viral analyzer]]. The evil cube is going with us.

We take the book “[[Naacal]] for dummies” with us.

![[north_borneo.jpg]]

As we approach - we see [[Night-guant|huge bats]] but its daylight. Then a crashing sound and a scream. The claws come through attached to:

![[night_guants.jpg]]

Sanity rolls to open next session, with [[Hugo Gustafsson|Hugo]] at a penalty die since it was in his dreams.

##### Navigation
[[Session 07 - New York]] | [[Two-Headed Serpent]] | [[Session 09 - North Borneo]]

