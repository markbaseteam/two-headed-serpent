---
sessiondate: 2022-01-24
sessionyear: 2022
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 09 - North Borneo
**Date:** 2022-01-24

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Max Tannenbaum]]
- [[Paul Schreiber]]

## Events
![[north_borneo_briefing.jpg]]

Sanity rolls a bit tough on the group. [[Amandus Winston Steel|Amandus]] did make his. Damn Germans and their flying machines. It sounds like the cockpit and hold have been compromised. These were in the walls back at the temple. [[Night-guant|Night-guants]] come to mind - they like to drop people from hight places. One is trying to ripe off the cowling to the engine and drop it into the blades.

We try to repeal the one pulling [[Hugo Gustafsson|Hugo]] out of the smashed plane window. As we damage the thing, we "hear" its scream in our head. [[Amandus Winston Steel|Amandus]] helpes Hugo with the plane. The others hold off the [[Night-guant|Night-guants]]. Amandus punches one that lands in the cockpit, allowing Hugo to focus on landing. The creature in the back might had damaged the special machine. One is really trying to pull [[Paul Schreiber|Paul]] out of the plane.

Going back to help out, [[Amandus Winston Steel|Amandus]] dislodges the last healthy one, but with its many limbs that grabs Amandus and yanks him out of the plane. Amandus hands him a grenade and wriggles free. He gets stung, but somehow is buffeted by treetops and somehow lands in extreme pain. Land in a pod of probiscus monkies.

![[north_borneo_monkey.jpg]]

After the crash, [[Quentin Shapiro|Shapiro]] turns white. Apparently a last resort bomb is about to go off Joseph….

[[Paul Schreiber|Paul]] knows:                           

- chest (20 x 20 x 30 inches). The box lies on its side, with one of the four larger faces being comprised of a two-part lid, attached by brass hinges on the longer sides. A rotating brass disc, inscribed with a four-pointed star, holds the lid in place.
- The four faces around the outside of the box are inscribed with patterns of stars, which a successful Astronomy roll reveals to be the constellations of Leo (northern face), Taurus (eastern face), Piscis Austrinus (southern face), and Scorpius (western face). On each face, silver strips inlaid into the wood form the lines between the stars. The majority of the stars are marked with citrine (yellow quartz), except for Regulus (Leo), Aldebaran (Taurus), Fomalhaut (Piscis Austrinus) and Antares (Scorpius), which are all marked by rubies. The aforementioned Astronomy roll also reveals that these are the “Royal Stars”—according to ancient Persian wisdom, the guardians of the sky, named Venant, Tascheter, Haftorang, and Satevi, were believed to hold both the power of good and evil.
- Across both halves of the lid, two fishes are carved, inlaid with gold. The mouths of both fishes are open and pointed towards one another, with the brass disc that keeps the box closed between them (corresponding to the position of Fomalhaut in Piscis Austrinus).
- The brass disc must be turned 360 degrees to open the lid. The interior of the box is filled with a complex series of rotating hoops, discs, wheels, and gears. All are made of brass and inscribed with astrological sigils that chart various paths through the celestial sphere. The entire mechanism resembles a strange armillary sphere, with a large tetrahedron made from a single ruby, about the size of a clenched fist, at its heart.
- A series of six dials, three at each end of the interior of the chest, are marked with the numbers 1 through 10 in Persian. Once one is turned, they all begin to click and turn, implying it might be a mechanism of some fashion to measure the passage of time.

Whatever this device is, its going to go off in 36 hours. Basically, it will open into the heart of the star - likely 5 mile radius. Off to the military base

### Hour 0/36

On the way, there seems to be a side trail that a very large creature passed (uprooted trees). That path is perpendicular to our path to the camp. We keep going to the base.

At the base, NW of Ranau:
- [[Captain Lancanster]]
- British & Sikh soliders
- First aid, then some exotic steak.

Luck refresh next session

##### Navigation
[[Session 08 - New York to North Borneo]] | [[Two-Headed Serpent]] | [[Session 10 - North Borneo]]

