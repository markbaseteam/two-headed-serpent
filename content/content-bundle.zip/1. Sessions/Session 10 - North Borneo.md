---
sessiondate: 2022-02-07
sessionyear: 2022
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 10 - North Borneo
**Date:** 2022-02-07

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Max Tannenbaum]]
- [[Paul Schreiber]]

## Events
Amandus is still down on his luck (only 13 back).

Handout - Mount Kinabalu Map
![[mount_kinabalu_map.jpg]]

### Hour 2/36 - At the base

Handout - Quarantine Zone Map
![[quarantine_zone_map.jpg]]

The creature that the steak came from is elephantish. Teeth at the end of the snout. There are tentacles, and horns. And its tasty. [[Amandus Winston Steel|Amandus]] claims there is a stuffed one of these at the British Natural History Museum. Others claim is something from the [[Dreamlands]]. Some claim they saw the creature on the mural back in Bolivia.

Mmmm, Tasty Mythos Steak.

After dinner, our supplies arrive. [[Captain Lancanster]] talks about getting to the survey site just up the road. [[Abaddin]] is a local guide and translator. Locals are protesting, thinking the survey team has caused the outbreak.

In the trucks, rerun across that T-Rex like print again. It seems to have ranged out of the mountains. We epicly fail in talking with [[Abaddin]] about what might be going on.

### Survey Camp

Some of the guards do not look so good. One just vomited up is innards! they are talking about evac (the British) but 10 have died, including the doctor. A good number in the tent will not make it overnight. They want to get back to work blasting stuff (see if its mining material). But there are tunnels and rumbling. A good 20 died in the blasting.

The nearby graves settled way to quickly, like the bodies are not there anymore.

Timeline:
- Blasting mid-Feb
- First week of March is when rumbling started.
- Protests week or two into March
- Sickness start around 18th of March (locals)
- Dr. died last week of March.
- Current is April 12

[[Quentin Shapiro|Shapiro]] gets to work. We leave the bomb behind. 8+ hours for the machine to do its job. We take distributor caps to keep people here.

### Hour 4/36 Leave Survey Camp - Looking for Tunnels

As we walk , we smell rotting fruit, more odd (but not huge) tracks. Getting dark. Then quiet. We have the guide.

Suddenly, [[Max Tannenbaum|Max]] is stuck in some sticky strands. A huge spider! Truck sized.

Image - [[Leng Spider|Giant Legged Creature]]
![[leng_spider.jpg]]

Cliffhanger!

##### Navigation
[[Session 09 - North Borneo]] | [[Two-Headed Serpent]] | [[Session 11 - North Borneo]]

