---
sessiondate: 2022-02-21
sessionyear: 2022
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 11 - North Borneo
**Date:** 2022-02-21

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Max Tannenbaum]]
- [[Paul Schreiber]]

## Events
Luck refresh - for once [[Amandus Winston Steel|Amandus]] crit failed - max luck!!

### Spider

[[Max Tannenbaum|Max]] is yanked up by the strand. All lose a bit of sanity. [[Joseph Laird|Joseph]] is not doing okay - stunned by turn of events. Irrational plan evolves. Hands out dynamite and says throw it. Joseph is envisioning that his brother died facing some horror like this.

[[Amandus Winston Steel|Amandus]] somehow recalls from the murals in the hallways and in the literature of [[Caduceus]] about the [[Leng Spider]] - very poisonous from the [[Dreamlands]]. Very intelligent, and webs are steel cables and like to cut off escape. Amandus tosses one of the sticks to keep open the escape route.

[[Hugo Gustafsson|Hugo]] tosses dynamite under and beyond the spider, it will boost [[Max Tannenbaum|Max]] up :-) . [[Paul Schreiber|Paul]] shot it, but it is rather hard. The spider whisks Max even higher. Max shouts at in [[Naacal|serpent person]] but it ignores him.

[[Joseph Laird|Joseph]] tries to toss the other dynamite away. It does not go far and he tackles [[Amandus Winston Steel|Amandus]] out of the blast zone. Trees fall but we roll out of the way, take minor injuries. Spider is now on the ground and dragging [[Max Tannenbaum|Max]] to the cliff. Amandus jumps up and blasts the burning strand between Max and the mouth of the creature (at 2 PD!). [[Paul Schreiber|Paul]] gets stuck in the webs as he burns the creature with the [[Gold Bracelet|snake bracelet]].

The creature, badly burned, wails and starts to retreat. It is unable to drag [[Max Tannenbaum|Max]] any further. Max escapes! We finish it off at range (yeah [[Amandus Winston Steel|Amandus]]).

### Hour 9/36 Survive Giant Spider 5 pm

All this foliate is non-native - maybe [[Dreamlands]]. Its headed in the direction of the surveyor camp We see [[Serpent Race|serpent people]] tracks going back that way as well also one set of human prints. There is a faint tune in the woods.

We hide from the music, then the creature comes out (we ate this earlier)

![[dreamlands_elephant.jpg]]

Looking around the trail, [[Joseph Laird|Joseph]] and [[Max Tannenbaum|Max]] see a tattered German uniform, but it’s now gone. Following snake person tracks.

Someone sees a nice little intelligent mouse stuck in the webbing. But a closer look is something much worse. [[Joseph Laird|Joseph]], well, he hears them. They do honor deals, one and all. If you give up your body its an honorable deed. Then snaps out of it.

![[dreamlands_rat.jpg]]

### At the bottom of the cliff
Something with bobbing head is closing. Somewhat stealthy for something that towers over moderate sized trees (25’) [[Hugo Gustafsson|Hugo]] is not stealthy. [[Amandus Winston Steel|Amandus]] stealthes, sees the following then runs (this is the large 3 toe-thing).

![[gug.jpg]]

Some of our winged friends are up the cliff. There is a human form climbing the cliff that disappears into a cave. [[Amandus Winston Steel|Amandus]] huffs back and recommends we leave. Some claim it was [[Quentin Shapiro|Shapiro]]. Hugo reasons Shapiro is a snake person.

Joseph knows it’s a [[Gug]], but has some insight to a city in the [[Dreamlands]].

### Hour 13/36. See the [[Gug]] but investigate the cliff 9 pm.

We climb the cliff in the fain flight, with [[Joseph Laird|Joseph]] and [[Amandus Winston Steel|Amandus]] saving [[Max Tannenbaum|Max]] from a fall. We get to a cave with silvery artificial light.

##### Navigation
[[Session 10 - North Borneo]] | [[Two-Headed Serpent]] | [[Session 12 - North Borneo]]

