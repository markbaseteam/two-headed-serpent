---
sessiondate: 2022-03-07
sessionyear: 2022
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 12 - North Borneo
**Date:** 2022-03-07

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Max Tannenbaum]]
- [[Paul Schreiber]]

## Events
Hexagonal corridor with white walls (perhaps ceramic) leading to the silvery artificial light. Everyone but [[Amandus Winston Steel|Amandus]] noticed a band of soldiers (German, maybe British) as we climbed. They had come out of one of the holes, Fake Germans, clearly. There is something spinning up ahead. Golden series of steps, and perhaps even a pyramid. Hmmm.

Six steps with engravings. Highly polished. Silver polished metal, Above the sound, from the control panel. [[Quentin Shapiro|Shapiro]] (or someone wearing a Shapiro suit).

We come around. The others notice no sweat and it is hot. Bad news, the analyzer says its very bad news. Time to nuke.

[[Paul Schreiber|Paul]] sees through this and burns him! Snake “hahaha you are too late. Our plans are already in motion. They have advanced the clock. We pass the san checks. Now his skin is turning liquid and black. We unload into him.

A chime goes off and all the hexagons speed up. More power into the system. There is a warning light button. [[Paul Schreiber|Paul]] thinks he can get the monitors on. Note everything is in [[Naacal]]. [[Hugo Gustafsson|Hugo]] looks at the journal - its in English

**North Borneo Pangea**
![](https://i.imgur.com/f5MUlUE.jpg)

Is that Pangea?

![[north_borneo_journal.jpg]]

Basically they are trying to open a gate to [[Mu]]. The bad guys think death powers the gates, thus  he [[Yellow Death|plague]]. But now it might be the bomb.

Got the screen to output (but we can’t read much of it)

**North Borneo Gates**
![[north_borneo_screen.jpg]]
![](https://i.imgur.com/AKcO1Fg.jpg)

Try to blow this thing up without blowing us up  well, fail. Something very large tunneling below us in the mountain. Looks like the world is starting to drain into a newly formed whirlpool

![[north_borneo_active_gate.jpg]]

(very bad)

[[Paul Schreiber|Paul]] lost it (19 lost sanity). [[Amandus Winston Steel|Amandus]] - “meh” (1, even though the horrible check). [[Joseph Laird|Joseph]], a bit crazy too. Then it spits out some green slime that hits us It pushes out the gate area, down the hall. Finally Joseph’s bomb goes off.

Pull out of the goo. Others start to suffocate in the goo. We escape. No batwings. There is something huge below us - perhaps another of of these creatures. Some of us are screaming is that this thing eat sword.

It is called a [[Dhole]] - from the [[Dreamlands]]

https://lovecraft.fandom.com/wiki/Dhole

[[Joseph Laird|Joseph]] gets a phobia - large sets of teeth

We agree, both sane and insane, think its time to go back to camp and put the bomb in the mountain.

### 20/36? Return to Camp - Daybreak (5:30 am)

Keep in mind [[Quentin Shapiro|Snakepiro]] might have had access to the bomb. Less sick people about. [[Viral Analyzer]] finish, has an output. Could look it up. Signs of a struggle - bits of shredded flesh. There is a bucket of human bones, gnawed. [[Paul Schreiber|Paul]] is not doing well (more sanity loss).

### Hour 20/24.5 Start back - Daybreak (5:30 AM)

The bomb; likely go off in 4.5 hours. We are 3 hours from edge of quarantine zone. One of the deep caves in 2 hours. We can drive part of the way. [[Amandus Winston Steel|Amandus]] drives like a crazy man to cut the time to an hour each way.

### Hours 21/24.5 at deep pit (6:30 am)

Lots of rumbles down there. [[Joseph Laird|Joseph]] wants the bomb to confront the worm. There’s meeps about, meeping. This slopes all the way down. We make a sled so the bomb slides down nicely +1 hour.

### Hour 23/24.5 At camp (8:30 am)

Load up machine, notes, and people that can go. [[Yellow Death]] bio-weapon. It will burn itself out. Likely kill current infested, but there are formula to detect and neutralize until it burns out.

We get the healthy survey. Get others to walk. Then the mountain explodes. Ball of white flame. Then volcano/lava

Then some of us throw up yellow puke. But we might have some hybridization.

![[north_borneo_2.jpg]]

##### Navigation
[[Session 11 - North Borneo]] | [[Two-Headed Serpent]] | [[Session 13 - New York]]

