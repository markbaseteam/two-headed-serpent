---
sessiondate: 2022-04-18
sessionyear: 2022
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 13 - New York
**Date:** 2022-04-18

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Max Tannenbaum]]
- [[Paul Schreiber]]

## Events
At this point, we can make something to stave off the disease for a week. Also a vaccine to stop infection. This is serpent biological weapon, and its near its burnout point.

Call in [[Caduceus]], Mention [[Sashinal|Rose Meadham]]. Are their 5th column. We take medicine and skin is yellow.

### Back to New York - April 21, 1933

[[Paul Schreiber|Paul]] and [[Amandus Winston Steel|Amandus]] are in quarantine, While we were in and out, there is a bunch of screaming We get cut open and large needles. [[Dr. Victor Gomes Goncalves|Goncalves]] does the debrief “It looks like it went well for them, the yellow fever weakened them and so it took better than the others”.

[[Sashinal|Rose]] had been taken over by [[Inner Night]] (serpent person). Now high ranking ([[Joshua Meadham|daugher of owner]] of [[Caduceus]]). [[Mu]] has tech that could control the human population. Their goal is to find Mu, then destroy the human race, and restore the serpents. Must use a gate to get there. Our [[The Queen|Snake Queen Lady]] has awoken but is not all that cooperative.

[[Joseph Laird|Joseph]] and [[Hugo Gustafsson|Hugo]] go to the club, met up with a mob boss - [[Bonanno family]], [[Giovonni Bonventre|Giovonni]]. Lots of mob interaction as Hugo high tails it out of there. They are interested in that [[Red Hook warehouse|Caduceus warehouse]]. Hugo goes home, there is a package from the big guy waiting for him. Bottle of liquor - thank you from your friends”.

[[Amandus Winston Steel|Amandus]] - charms the nurse. But if you do get hurt, but you are more resilient, Accelerated cellular regeneration. Sounds like injury might….change us. Amandus gets a date with the nurse and that is good enough. [[Paul Schreiber|Paul]] checks the equipment. [[Dr. Julia Smith]].

Paranoia starts to creep up. We get about 1 week R&R. But there is something brewing in OK city.

[[The Queen|Snake Queen]] asks about us, wants to chat.

##### Navigation
[[Session 12 - North Borneo]] | [[Two-Headed Serpent]] | [[Session 14 - New York]]

