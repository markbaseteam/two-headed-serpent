---
sessiondate: 2022-05-02
sessionyear: 2022
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 14 - New York
**Date:** 2022-05-02

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Max Tannenbaum]]
- [[Paul Schreiber]]

## Events
[[Amandus Winston Steel|Amandus]] - “Once you go scales, everyone else pales”

### Go to the sub-basement.

Its like Q in 007, except with weird artifacts, [[Paul Schreiber|Paul]] plays around with items.

### To the Queen!

[[The Queen|She]] is reported to be grumpy. We go in anyway. Chick hits on [[Amandus Winston Steel|Amandus]]. [[Caduceus]] is annoying her with questions. 1000s of years since we lost glorious [[Mu]].

They are aligned to [[Yig]], but squabbles with the frog god ([[Tsathoggua]]). Yig was “just a person”. Yig is really not all that good. She digs humans, her 3rd husband was one.

Later, she does offer to bind us to her dreams so we can connect in the dreamworld. [[Amandus Winston Steel|Amandus]] is interested due to his own bad dream.

We meet and decide to investigate this warehouse. We are trying to get a handle on what [[Caduceus]] really is.

##### Navigation
[[Session 13 - New York]] | [[Two-Headed Serpent]] | [[Session 15 - New York]]

