---
sessiondate: 2022-05-16
sessionyear: 2022
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 15 - New York
**Date:** 2022-05-16

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Max Tannenbaum]]
- [[Paul Schreiber]]

## Events
Going to watch King Kong. Later talk to the [[Miles Miller|dude]] that worked at warehouse. There is a little package in the room. From landlord. Its a nice package of alcohol. Whiskey. [[Phillip Conners]] Favorite - last time in NY - the quartermaster.

Tries to interact to improve sanity - in the boarding room - out on the balcony - breeze lows the [[Stephanie|lock away]] into an alley - a claw in a British uniform grabs the lock and kisses it. Face is similar to her in a weird way. Then gone. Starts drinking the whiskey.

We all get a small gift, seemly from [[Caduceus]] or the mob.

Then the dreams.
- [[Hugo Gustafsson|Hugo]] - wife dying of TB from mosquito
- [[Amandus Winston Steel|Amandus]] - the pit - the wrong gf, familiar, weird. Maybe there was something - a tittering - watching. Did they follow back to NYC?
- [[Joseph Laird|Joseph]] - in [[Thaddeus Laird|brothers body]], dark cave. Some sort of medical procedure. Dinosaur head.
- [[Paul Schreiber|Paul]] - things hover off the page - a portal - worm creature. [[Paul's Grandfather|Grandfather]] - "don't look"

Date with [[Dr. Julia Smith]] - Dinner and King Kong - flirting. She does not seem to know much about it. Typical date stuff. Lots of talk of disection, mostly reptiles. Will have second date. Not sure she is Capy-worthy.

[[Joshua Meadham]] - [[The Queen]] does not like.

She might be have some use in getting the Queen to escape. Similar access, but she know them and way around. She lives in a womans boarding house.

[[Hugo Gustafsson|Hugo]] brings mice and reads scrolls

**Handout - Annals of Mu**
![[annals_of_mu.jpg]]


### Monday Lunchtime

**Handout - Security Letter**
![[temple_security_letter.jpg]]

We do talk about if we should tell [[Caduceus]] about the warehouse. Note the secretary harassment stopped once [[Max Tannenbaum|Max]] talked to his people. Discuss next time.

##### Navigation
[[Session 14 - New York]] | [[Two-Headed Serpent]] | [[Session 16 - New York]]

