---
sessiondate: 2022-05-30
sessionyear: 2022
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 16 - New York
**Date:** 2022-05-30

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Max Tannenbaum]]
- [[Paul Schreiber]]

## Events
[[Max Tannenbaum|Max]] recovers from [[Yellow Death]]. He now has disco fever. He has been "worked over" - clearly something has changed in his body. Wanders and likely finds [[the queen]]. Hears [[Naacal]], and also hears "will not serve [[Father of Snakes]] and [[Mother of Darkness]]." They shot her up with something. Door shut.

Joins us up on the 8th floor. We sweep the room for listening devices - its clean. He has signs of surgery. Does recall dream's surgery and glass tubes.

[[Max Tannenbaum|Max]] does a reading on his scars - in a cave and surgery by [[Serpent Race|Serpent people]]. Impression of pressure on the scars. Snake Drs. allows them to scale up operations.... (nice, two puns in one sentence).

### Red Hook Warehouse Research
[[Amandus Winston Steel|Amandus]] and [[Joseph Laird|Joseph]] working on [[Red Hook warehouse|the warehouse]]:
- Find some information in the library (start Monday, end of Tuesday)
- Many stored pharmaceutical, including Red Hook.
- Second warehouse is a quick passthough.
- Seems like more comes in than goes out.
- [[Dimethyl phthalate]] is a common shipment.
- 30 guards on the "empty" and 1 on the "full"
- [[Miles Miller|Amandus' buddy]] is outside the "empty" warehouse.

https://pubchem.ncbi.nlm.nih.gov/compound/Dimethyl-phthalate

[[Max Tannenbaum|Max]] and [[Hugo Gustafsson|Hugo]] to go to [[Dr. Victor Gomes Goncalves|Goncalves]]. Hugo is not happy.
- Confronts about [[the Queen]]
- [[Dr. Victor Gomes Goncalves|Goncalves]] is evasive and bureaucratic.
	- He does want to get info about [[Mu]] out of her
	- "keeping humanity safe"
- [[Hugo Gustafsson|Hugo]] accuses of using drugs to get her to talk.

### Visit the Queen
On Tuesday, go talk to [[the Queen]]
- Happy to see [[Hugo Gustafsson|Hugo]], she is groggy.
- Remembers [[Max Tannenbaum|Max]]. Smells different
- Hybridization. Its does not come to her. But [[Max Tannenbaum|Max]] sense she is being evasive.
- Tip her about the mic
- There are a few fresh cleaned up blood stains.
- She has a few cards up her sleeve, so to speak, that she is getting to the end of her options.
- [[Hugo Gustafsson|Hugo]] confesses his weird dreams. Some can be subconscious. But she says part of this is clearly a [[Night-guant]]. She could help with that.
- [[Max Tannenbaum|Max]] wants the dream binding. A simple spell.
- [[Max Tannenbaum|Max]] super crit fails the drug - industrial food additive

### Dinner Together
Tuesday Evening 

At the Pub, [[Amandus Winston Steel|Amandus]]tells the tale (sounds like a tall tale). Confirms the warehouse information. Unlabled crates. Inside guards do not mix with the outside (5-6 inside). Lots of unmarked vehicles. There is stuff in there. Day shift.

[[Max Tannenbaum|Max]] had a decent San roll to recover :)

Dinner with [[Max Tannenbaum|Max]] - meet the [[Max's Granddaughter|granddaughter]]. Bring [[Capy]]

TBD

Wednesday April 26, 1933

https://www.generalblue.com/calendar/1933  

##### Navigation
[[Session 15 - New York]] | [[Two-Headed Serpent]] | [[Session 17 - New York to Oklahoma]]

