---
sessiondate: 2022-06-13
sessionyear: 2022
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 17 - New York to Oklahoma
**Date:** 2022-06-13

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Max Tannenbaum]]
- [[Paul Schreiber]]

## Events
[[Paul Schreiber|Paul]] talks with [[Paul's Grandfather|Grandfather]] - learns mind-blowing things, gets a box of old papers.

[[Amandus Winston Steel|Amandus]] - [[Dreamlink]] with the [[The Queen|Serpent Queen]].

Meet the [[Joshua Meadham|old man]] that runs this place.

[[Canning]] - Seems grumpy, tries to intimidate us. [[Paul Schreiber|Paul]] and [[Hugo Gustafsson|Hugo]] are not impressed.

Cult worshipping [[Yig]] in OK, posing as a Christian Cult. [[Hugo Gustafsson|Hugo]] raises the treatment issue of [[the Queen]]. [[Dr. Victor Gomes Goncalves|Goncalves]] is a bit uncomfortable with the discussions.

Genesis 3:14 - [[Naacal]] in the background - go to the town of Bingham to seek trust. Those that failed a Power Check are chomping at the bit to go to Bingham ([[Hugo Gustafsson|Hugo]], [[Paul Schreiber|Paul]]). Be sure to separate people from the real [[Inner Night]]. Male Skeleton on display for 20 years, older bodies.

Package of materials.  

##### Navigation
[[Session 16 - New York]] | [[Two-Headed Serpent]] | [[Session 18 - New York to Oklahoma]]