---
sessiondate: 2022-06-27
sessionyear: 2022
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 18 - New York to Oklahoma
**Date:** 2022-06-27

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Max Tannenbaum]]
- [[Paul Schreiber]]

## Events
To Oklahoma!

![[oklahoma_airplane.jpg]]

Then the Mission Brief

![[oklahoma_briefing.jpg]]
![[oklahoma_bingham_1.jpg]]

[[Hugo Gustafsson|Hugo]] really wants to get there, and lands near the town. Note we have like 5 types of venom of mass destruction.

Desiccating Venom, Dissolving Venom, Explosive Venom, Mind-Killing venom, skin-shedding venom

[[Joseph Laird|Joseph]] has [[Charles Rome|enemies]] in OK. (crit fail).

### Friday, April 28, 1933

Land late on Friday.

![[oklahoma.jpg]]

Its a rough flight. And a rougher landing. Mistakes were made and repairs will be needed.

#### Into the Town of Bingham

#####  Lady on the Roof
There is a shimmering form of a woman on a roof of an abandoned building off of 1st street. Serpent style clothes. Or naked! She is shedding skin. She does not want her husband to know. Her skin is oddly gray. Skin is just flying off her onto us. The Adams will take care of us at the hotel.

The reverd cured her skins condition. Her husband is a grump blacksmith. She makes us some scaley lemonade. Rev has been gifted to heal. Has been here his entire life, but did a recent stint in the wilderness (40 days/nights, back 3 months ago) with this power.

Husband keeps her locked away. [[George Hensen]], saved him after an accident at the lumbermill (broken spine). In two days she will be good as new. [[Amandus Winston Steel|Amandus]] does drink, but its not good.

Note: it is the start of the Dust Bowl. Is it her? Pearl.

![[pearl_schoenbaum.jpg]]

##### The Hotel
The Bingham Hotel. Lots of lifelike figurines. [[Delbert Adams]]. Pushing the Reverend. Very snake themed. [[Rosemary Adams]] has the figurines. Now very judgmental. [[Hugo Gustafsson|Hugo]] buys a figuring.

**Delbert & Rosemary Adams - Bingham Hotel**
![[delbert_adams.jpg]] ![[rosemary_adams.jpg]]

Most recent - [[Mortimer and Lloyd]] last people to sign in.

![[mortimer.jpg]] ![[lloyd.jpg]]

##### To the Saloon.

People are quiet at first, then resume talking.

Oddly, this guy is anti-snake and says get out of town. Snake bite. [[Hilliard Fowler|Hillard]] says the [[Reverend Kornfield|Rev]] is cursed by the devil. Pretty much the whole place is just get out, the place is messed up. One lady says [[George Hensen|her husband]] just falls asleep under the house. Becoming snake like. Gregory's baby - [[Peggy Shaw|Peggy]] - Rev cursed their baby - they stay inside. [[Gregory Shaw|Gregory]] is here.

[[Reverend Kornfield]] went south on his pilgrimage.

[[Susie Schoenbaum]]

![[susie_schoenbaum.jpg]]

[[Bill Schoenbaum]] - the blacksmith

[[Pearl Schoenbaum]] - skin shedding lady

![[pearl_schoenbaum.jpg]]

[[George Hensen]] - lumbermill - under the house

[[Hilliard Fowler]] - Drunk Lumberyard owner

![[hilliard_fowler.jpg]]

[[Edna Hensen]] - who you talked to last night

![[edna_hensen.jpg]]

[[Gregory Shaw]] - mad

![[gregory_shaw.jpg]]

[[Peggy Shaw]] - weird baby

[[Maurice Walsted]] - Deer Head Salon

![[maurice_walsted.jpg]]

[[Augusta Willis]] - Librarian

![[augusta_willis.jpg]]

[[Edith Kunkel]] - co-owner of barbershop, husband was healed by the rev

[[Harry Mathewson]] - barbershop caretaker, healed by reverend, ate pig

[[Ralph Kunkel]] - healed by Rev

### Saturday, April 29, 1933

#### Morning Service
[[Reverend Kornfield]]

![[reverend_kornfield.jpg]]

Off to the morning service. Wooden crate near the front - likely full of snakes. Lots of Adam/Eve/Snake pics. Lots of snakes. Big family bible on the lecture with recent scribbles and annotated.

Sermon - [[Yig]] woven in with Jesus. The Serpent is really god passing wisdom to man.

Then the snakes come out and we are protected by your lord and savior [[Yig]].

Time for the church to go up (fire! from the drunk guy). [[Amandus Winston Steel|Amandus]] sneaks the book out in the middle of all the chaos. Paul gets a bit scorched getting out. Note the sheriff is in the congregation.

[[Sheriff Benson]]

![[sheriff_benson.jpg]]

We see the two youngsters fleeing the scene. [[Gregory Shaw|Gregory]] and [[Susie Schoenbaum|Susie]].

![[gregory_shaw.jpg]] ![[susie_schoenbaum.jpg]]

The crew helps to put out the fire. [[Sheriff Benson|Sherriff]] asks if [[Amandus Winston Steel|Amandus]] help to find the miscreants.

Church is lost, but the evening services are still on!

P E T R O L - what a funny way to spell Water

![[oklahoma_bingham_2.jpg]]

##### Navigation
[[Session 17 - New York to Oklahoma]] | [[Two-Headed Serpent]] | [[Session 19 - Oklahoma]]