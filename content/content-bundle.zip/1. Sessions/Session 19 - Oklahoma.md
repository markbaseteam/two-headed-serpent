---
sessiondate: 2022-07-25
sessionyear: 2022
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 19 - Oklahoma
**Date:** 2022-07-25

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Max Tannenbaum]]
- [[Paul Schreiber]]

## Events
![[oklahoma_snakes.jpg]]

### Dolls

So whats up with the creepy dolls? [[Paul Schreiber|Paul]] is going check them out.

[[Clea Butler]], owner of the Butler Department Store (10) - got some tools and crowbars.

[[Paul Schreiber|Paul]] and [[Joseph Laird|Joseph]] investigate the dolls. Just seems to be creepy dolls. They start looking at the [[Gospel of Yig|bible]]. So far, normal.

### Lumberyard

[[Hugo Gustafsson|Hugo]] and [[Amandus Winston Steel|Amandus]] to the lumberyard. Meet [[George Hensen|Edna's husband]], the man healed from the lumberyard.

One has to be chosen for the pilgrimage.

### The Bible

Paul working through
- does discover there is a spell to contact [[Yig]].
	- Needs a sacrifice (not necessarily human)
	- A potion with a base of snake poison (plenty of sacred snakes around here)
	- [[Naacal]]
	- Emotional loyal to [[Yig]] (advise his children through the sacrifice)
- Hurting any serpent offends [[Yig]]

There is a timeline of the journey, revelation, etc in the Bible. List of who went with him on another journey (one is the [[Sheriff Benson|Sheriff]], and [[Harry Mathewson|Old Harry]])

### Radio Home

[[Joseph Laird|Joseph]] calls in to [[Dr. Victor Gomes Goncalves|Goncalves]]. He calls is it starting miracle about [[Yig]]. Want us to check and see if the [[Reverend Kornfield|preacher]] is a [[Serpent Race|snake person]].

### To the blacksmith shop.

We do not mention [[Pearl Schoenbaum|his wife]], but mention the [[Sheriff Benson|sheriff]] might be looking for the people.

We can borrow his truck.

### To the Posse

Its a semi-angry mob. To the [[The First Church|church]]! The good thing is there are a large number of people messing up the trail. But there is a good line that we need to mess up. We scuff the trail just enough.

### Blacksmith

[[Bill Schoenbaum]]- the blacksmith. The [[Sheriff Benson|Sheriff]] pushes to go there . At least we might the better truck. For whatever reason [[Hugo Gustafsson|Hugo]] was trying to agitate the crowd, [[Amandus Winston Steel|Amandus]] calms them a bit.

Get to the blacksmith shop. Wants to talk to [[Susie Schoenbaum|Susie]]. [[Sheriff Benson|Sheriff]] punches Bill. Still trying to get Susie.

After talking, [[Bill Schoenbaum|Bill]] comes with the [[Sheriff Benson|Sheriff]] to answer questions. We work our way in.

[[Hugo Gustafsson|Hugo]] tries to get the sheriff in trouble with the press, but the news is fake. But she does throw out something torture at the barbershop.

[[Amandus Winston Steel|Amandus]] "shows them how its done" - looks horrifically brutal but he communicates to [[Bill Schoenbaum|the blacksmith]] to roll with the punches.

### The Evening Service

Themes of forgiveness, coming forward to repent. Tests by [[Yig]]. [[Joseph Laird|Joseph]] and [[Amandus Winston Steel|Amandus]] see a glint from an nearby building - sniper! Amandus yells out. [[Hugo Gustafsson|Hugo]] tries to protect one person from the snakes as this all goes on.

[[Reverend Kornfield]] fails to dodge, mystery person misses badly. But GM cheats and hits (aim, bonus die).

The [[Sheriff Benson|Sheriff]] returns fire and hits the assassin. [[Reverend Kornfield|Rev Kornfield]] dead, snakes converge on [[Hugo Gustafsson|Hugo]].

![[oklahoma_bingham_3.jpg]]

##### Navigation
[[Session 18 - New York to Oklahoma]] | [[Two-Headed Serpent]] | [[Session 20 - Oklahoma to New York]]

