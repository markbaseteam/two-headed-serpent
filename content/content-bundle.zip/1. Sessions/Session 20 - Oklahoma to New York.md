---
sessiondate: 2022-08-08
sessionyear: 2022
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 20
**Date:** 2022-08-08

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Max Tannenbaum]]
- [[Paul Schreiber]]

## Events
Then a scream in pain - [[Clea Butler]] was holding a rattlesnake - she screams as the snake is now hostile, as is the crate of snakes.

[[Gregory Shaw]] involved.

[[Hugo Gustafsson|Hugo]] wants to take the preacher to the sacred place. Snakes follow. Hugo messes with the [[Sheriff Benson|Sheriff]], accusing him of being in on the assassin. Hugo makes the sheriff pick up a snake. The snakes hisses, then bites him!

[[Hugo Gustafsson|Hugo]] just murdered the [[Sheriff Benson|Sheriff]] in cold blood! Although he might survive.

We get a truck ([[Delbert Adams]]), lots of snake follow. Someone knows where the sacred place is. We go. Out in the desert, he then "releases" snakes.

Drives another truck (all the followers want to go) - [[Pearl Schoenbaum]] - but her skins is new and pristine.

[[Harry Mathewson|Old Harry]] - Dude with a pig stomach? Knows how to get there.

[[Amandus Winston Steel|Amandus]] gets there - the Assassin is [[Hilliard Fowler]] - Drunk Lumberyard owner - Amandus applies first aid to save him. Gets him to that discontented bar before joining the exodus.

### Cave the Desert

There is a wind from the cave - must of us not effected ... except for [[Joseph Laird|Joseph]]. He must not be a believer :). [[Amandus Winston Steel|Amandus]] tries to help him. Despite the wind, Amandus easily carries him in. Once in, no wind!

Around a bend...there is a gasp ... there is a corpse on a slab - a perfectly preserved body of [[Reverend Kornfield|Rev Kornfield]]! Then another version emerges from the body

![[kornfield_emerges.jpg]]

New [[Reverend Kornfield|Kornfield]] gathers his memories and starts to talking about [[Yig]]. "The Yig is Up!" There is some Yigness all around.

[[Paul Schreiber|Paul]] burns these abominations! (uses [[Gold Bracelet|flame bracelet]]). Note - it did not have a belly button.

Suddenly, the pressures release and things feel normal.

From the [[Gospel of Yig|Bible]], it seems as if the [[Reverend Kornfield|reverend]] wandered the desert and found this place, and died here.

Now the poisons kick back in, and the [[Sheriff Benson|Sheriff]] dies. [[Hugo Gustafsson|Hugo]] is a murderer. Hugo tries to give the crowd direction, but does poorly.

Those that had been "healed" still have their interesting effects.

### Back to Town

[[Amandus Winston Steel|Amandus]] does hear that about three guys in trench coats where looking for us. Came in on the train. Might be our [[Charles Rome|mob friends]]. Looking for [[Joseph Laird|Joseph]]- some bad blood.

We collected our effects, repair the plane, and leave just before the mobsters show up!

A job well done- everyone mad us.

![[gospel_of_yig.jpg]]

End of the chapter.Sanity/Luck/Skills.

### Back to NYC

#### Monday, May 1, 1933 (late)

We might get a bit of rest, but Iceland might be calling. Volcano might blow up due to an [[Inner Night]] Event.

[[Amandus Winston Steel|Amandus]] checks in on [[Capy]] and tells stories no one believes, except for Capy who always believes me.

#### Dreams

- [[Amandus Winston Steel|Amandus]] - In a cave, skittering. A lock of hair blows by (I am over there). There is [[the Queen]]. "Can you do anything soon?" Sure soon. She does not seem happy with tthat answer. She might make her move in the next a couple of days.
- [[Hugo Gustafsson|Hugo]] - That mosquito dream. It gets big and looks him while it sucks her blood.
- [[Paul Schreiber|Paul]] - in apartment - hear breathing - obsidian with [[Naacal]] symbols. It breaths.
- [[Joseph Laird|Joseph]] - a nice night of sleep - no bad dreams.

#### Tuesday May 2, 1933

[[Amandus Winston Steel|Amandus]] talks to [[Hugo Gustafsson|Hugo]] about how restless [[The Queen|his girlfriend]] is getting.

Invitation to [[Green Garden Cafe]], 7pm - [[Bonanno Family|the Mob]] is going to move on the [[Red Hook warehouse|warehouse]].

![[kornfield_snakes.jpg]]

##### Navigation
[[Session 19 - Oklahoma]] | [[Two-Headed Serpent]] | [[Session 21 - New York]]

