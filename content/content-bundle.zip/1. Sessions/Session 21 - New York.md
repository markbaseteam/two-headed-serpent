---
sessiondate: 2022-08-22
sessionyear: 2022
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 21 - New York
**Date:** 2022-08-22

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Max Tannenbaum]]
- [[Paul Schreiber]]

## Events
![[letter_from_uncle_john.png]]  

[[Paul Schreiber|Paul]] tapped into a listening stone of some short (we are in Eberron now Gnomes everywhere). We are known as that “Pesky Bolivia Team” the PBT. He did not recognized the voices. They might be looking for us if we go to Iceland. They are also worried about the Congo. Search for a gate to [[Mu]], might be in South America. [[Sashinal]] (left Iceland for South Amercia, but no hiding what happened there), [[Mob Team Leader]], [[Caducius Team Leader]]. 

We get a call to get the Iceland briefing about 1pm. 

But before. [[Hugo Gustafsson|Hugo]] goes in to visit [[the Queen]]. She seems to be taking things into her own claws/hands. She is not happy and there are bodies. She pops open a portal, but offers [[Hugo Gustafsson|Hugo]] the [[Dreamlink]]. She is search for her [[Cobra Crown|crown]] and [[Serpent Scepter|sceptre]] (that Hugo has...). She needs them for the next phase in her plan. She steps in after linking with Hugo. 

[[Hugo Gustafsson|Hugo]] berates them for mistreating [[the Queen]]. 

Meet and compare notes. [[Miles Miller|Warehouse Miles]] will be working the [[Red Hook warehouse]] tonight. [[Amandus Winston Steel|Amandus]] gets word to call in sick. We decide to tell both [[Caduceus]] and [[Bonanno Family|the mob]] what is going down at the warehouse. 

### Tuesday May 2,1933 1PM 

Have a note to see [[Dr. Julia Smith|Dr. Smith]]. 

[[Dr. Victor Gomes Goncalves|Goncalves]] recognizes [[Sashinal]] its head of [[Inner Night]]-Has the body of the daugher of the [[Joshua Meadham|founder]]. 

![[snaefellsnes_peninsula.png]]

Talk with the [[Caduceus]] security ([[Francesca De Luca]]) about the [[Red Hook warehouse|warehouse]]. 

Not true form of [[Yig]] Fake Yig= Fig... 

Then says if we get back from Iceland we might get the true form of Yig=Trig. 

Iceland - Reawaked volcano and tremors. And Trolls! Vormies - [[Serpent Race|serpent people]] engineered the trolls. Trolls are tough strong, but subservient and easily cowed. 

Note: [[Inner Night]] is more direct less subtle and non-scientific approach. 

This is a recon mission and report back (unless an obvious switch to turn it on. 

Secondary - If breech facility, there is a room with metal canisters. Secure one if we can. They might be able to gain insight. So not open - fragile. 

There is a small base, tier 1 team, and a guide. We are “there to see how many have survived”. 

[[Caduceus]] has spies embedded with [[Inner Night]]. There is a [[Serpent Race|snake person]] facility there.  

See [[Dr. Julia Smith|Dr. Smith]]. Someone left a package with her for me. There is an book - tuft of hair from that weird dream with [[Stephanie|dead girlfriend]]. Book is called *Excerpts from [[Cultes des Goules]]* translated into English. We will meet after work as she has concerns about people around the building. Keep the hair, pass the book to [[Paul Schreiber|Paul]]. The hair was on page that is used to contact ghouls. 

[Cultes_des_Goules](https://lovecraft.fandom.com/wiki/Cultes_des_Goules)

A sit down with [[Hugo Gustafsson|Hugo]] and [[Dr. Victor Gomes Goncalves|Goncalves]]. Hugo brings down the hammer. Goncalves is “past is past - its a pity”.

[[Joseph Laird|Joseph]] meets with [[Giovonni Bonventre|Uncle John]] and asks to stay away from

##### Navigation
[[Session 20 - Oklahoma to New York]] | [[Two-Headed Serpent]] | [[Session 22 - Iceland]]

