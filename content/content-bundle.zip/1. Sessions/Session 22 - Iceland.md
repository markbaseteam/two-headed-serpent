---
sessiondate: 2022-09-19
sessionyear: 2022
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 22 - Iceland
**Date:** 2022-09-19

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Max Tannenbaum]]
- [[Paul Schreiber]]

## Events

### Wednesday May 3, 1933
Get picture of [[Sashinal|Rose Meadham]]. She looks [[Stephanie|Amandus' dead girlfriend]].  
![](https://i.imgur.com/nD9eBtz.png)

#### Leave for Iceland  
Bring dynamite for reconnaissance purposes.  

![[sikorsky_s_40.jpg]]

### Wednesday May 10, 1933  
Arrive at [[Caduceus]] camp.

![](https://i.imgur.com/SHpOHeT.png)

Met by [[Gunnhildur Jensdottir]].
![[gunnhildur_jensdottir.png]]

Does tours to the volcano in normal times. Temp is in the mid to high 30s and the day is 18 hours. Volcano is Snaefellsjokull Luck refresh. 

On the way - A boulder hits the first truck! Troll!  

![](https://i.imgur.com/STbk1vm.png)

Much bigger than the briefing (size 300 vs our 70). Gunn freaks, Arnandus picks up Gunn and takes her to the other truck We get our gear and dynamite. Troll is about to throw again. We high tail it out of there. 

After calming down, she notes her brother in a village near the volcano had seen trolls. She did not believe until now. 

#### Olafsvik  
It looks abandoned. [[Gunnhildur Jensdottir|Gunnhildur]] runs off to find her brother. Half stone trolls. There is a Capybara there tool. Signs for violence but no bodies. Life looks interrupted. but left orderly. On the door is a large handprint - just a bit too big to be human. [[Amandus Winston Steel|Amandus]] finds a journal some gossip. There are some hints of trolls, large ones. 

The trolls lead the humans toward the volcano. There is a glint in the sky - a fast moving UFO. 

Find a troll under rubble (140 size - so biggish). It is fearful of [[Naacal]], does not understand English. It has some short of collar. Its damaged and sparking. Get the collar off, and it seems grateful. 

Perhaps the trolls were controlled. [[Amandus Winston Steel|Amandus]] brings [[Gunnhildur Jensdottir|Gunnhildur]] over. She wants to shoot the troll with a rifle. Arnandus’ charm continues to fail him (“If you pull out a gun, you do not talk you shoot”). [[Joseph Laird|Joseph]] shows her the collar and says they were controlled. That works. 

We follow the path with the villagers. Get to the mountain. There is a secret access. Then we hear a click from inside and the door silently opens. An industrial passageway - carved out of the rock. it seems that our part serpent folkness might have opened the door.

##### Navigation
[[Session 21 - New York]] | [[Two-Headed Serpent]] | [[Session 23 - Iceland]]

