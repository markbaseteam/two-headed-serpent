---
sessiondate: 2022-10-17
sessionyear: 2022
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 23 - Iceland
**Date:** 2022-10-17

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Max Tannenbaum]]
- [[Paul Schreiber]]

## Events

Bad trolls. No tire. 

Damn huge facility. A few red lights here and there. Panels on the ceiling. Some signs of seismic activity. We explore this alien facility. Seems more industrial than North Borneo. Less decorated than Bolivia. 

[[Paul Schreiber|Paul]] pries the pivot point, and things go bad (failed Push). Rocks fall, but we mostly survive. [[Amandus Winston Steel|Amandus]] hears hissy American English from down the hall. They mention to taking a [[transport sphere]] out due to the tremors. 

Note its a bit cold in here. There is a mutant giant baby...carrying flame pistols. And a snake person. [[Amandus Winston Steel|Amandus]] steps out, sees it, and does not hesitate to give one both barrels. it goes down with a scream. Amandus pulls back. Somehow there is recognition in the eyes of one of them. [[Hugo Gustafsson|Hugo]] blasts the other. We grab the flame pistols and hear the call for reinforcements. 

[[Amandus Winston Steel|Amandus]] is out in the open when some large serpent person comes around the corner. It lashes out with its tongue. And more babies. 

![](https://i.imgur.com/WGPSnAI.png)

We flee. Head east on the map. There is muffled screaming ahead. Beyond is a pit. Long hallway to the north, mechanical whooshing sounds. Kick open the door with the screams. More giant babies, but there is a pen of naked Icelanders with a tube. Probably something to convert them. Very messed up things in this tube. They have extracted his skeleton somehow. The babies are running a panel. 

[[Joseph Laird|Joseph]] just unloads onto one of the babies (01!). [[Paul Schreiber|Paul]] misses with the flame gun and it catches a control panel on fire. [[Amandus Winston Steel|Amandus]] comes in but hesitates for a moment. Mercy kill or kill the baby scientist? Scientist. 

[[Amandus Winston Steel|Amandus]] finds some disconnected equipment that one can use to barricade the door. Others look to put out the fire. [[Hugo Gustafsson|Hugo]] gets the fire out. Buttons are pushed to get the people out of the tube. 

They babble. More Icelanders, babies and trolls to the east. “[[The Sleeper]] is awaking.” [[Serpent Race|Snake people]] can paralyze. Note that the Trolls fear the Snake People. 

Head east to the holding pens. Horrible smell. And Trolls with a cart with human remains. In the pit are three trolls that are very large . 25’tall. Eating. The ones up top seem to be choosing not to engage. A bit more intelligent. We try to remove their collars. We get them off. 

Others coming, [[the Sleeper]] is awaking faster than expected. They wonder why they are messing around with this other stuff instead an of leaving. Trolls leave to the east. It goes to a giant pit were there are trolls that could not be controlled. 

Find a room of vast with mechanical arms. Its not good. A giant eyeball looks back from the vat. “Reminds me of my ex-gf” 

Continue on, hoping to find the rest of the Icelanders. Trolls have a way out. Find another room that has them. Capture a Baby, they want to get most out of the base before it ends. Not enough [[Stone Serum]] to keep [[the Sleeper]] asleep. Its under the entire penisula. They have to mine it. They do not understand what they are doing. Get him to release the prisoners. 

The giant baby to [[Amandus Winston Steel|Amandus]] - you smell like us, why are you fighting us? He wants to lead us to a transport to get out. Lead to a huge open area.

### Cliffhanger

The Baby tries to escape. to some half shell. We play next week.

##### Navigation
[[Session 22 - Iceland]] | [[Two-Headed Serpent]] | [[Session 24 - Iceland]]

