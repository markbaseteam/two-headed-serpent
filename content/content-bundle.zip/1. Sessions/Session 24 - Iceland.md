---
sessiondate: 2022-10-24
sessionyear: 2022
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: ""
---
# Session 24 - Iceland
**Date:** 2022-10-24

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Max Tannenbaum]]
- [[Paul Schreiber]]

## Events
- Joseph shoots the fleeing snake person
- Joseph can see across the giant pit and there is a statue of [[Tsathoggua]] and more trolls on the other side
![](https://i.imgur.com/lXjM6z0.png)
- Paul realizes the abyss is probably a gigantic troll when it suddenly smells like the outside
- Paul and Hugo will try to repair the [[Transport Sphere]], Joseph will keep watch
- Amandus will sneak back to free [[Gunnhildur Jensdottir|Gunnhildur's]] brother, Ollie
- Giant serpent person appears and tongue latches onto Amandus
	- swipes Amandus with its claws
	- Joseph hears Amandus cry out and runs out to check
- Hugo works on the sphere and Paul figures out it mentally attunes with the user
- Paul tries to figure out more and faints
	- feels pin pricks and numbing sensation on his face
	- hand appears to be burnt
	- he wants to go find what is being injected into [[The Sleeper]]
- Amandus tries to convince the large serpent person he is a serpent person as well
	- realize it is just naked aggression and hungry
	- Joseph shoots the large serpent and it drops Amandus
	- Amandus shoots it with his shotgun, killing it 
- Group talks Paul down
- Joseph hears "Self Destruct paused at 5" in [[Naacal]], not sure of the time measurement
- Decide to explore more of the complex, but not sure what to do with the Icelanders
- Joseph thinks he can blow up the rocks blocking the entrance and they can flew there
	- goes to set the dyanmite
	- Amandus sets several capybaras and other animals
	- two [[Serpent Race|Serpent people]] in baby suits 
	- Amandus shoots one and it tries to surrender in English
	- The other tries to shoot Amandus with a [[Gold Bracelet|flame bracelet]] and tells the other one it should have been injected with [[Stone Serium]] in [[Naacal]]
	- Hugo comes up but misses his shot
	- Amandus kills the second serpent person and Hugo finishes the first
	- get one flames bracelet and one silver injector gun
- Joseph gets the Icelanders out the main entrance, telling Ollie where they last left his sister
- Amandus gets the capybaras out the entrance
- Head towards the stairs leading down to the north
- Joseph thinks he knows where the Self Destruct message was coming from
- Also see large room with several of the [[Transport Sphere|Transport Spheres]]
- Go to room where message came from and see several screens
- More industrial than North Borneo
- Find map that says we are in Geothermal Core
- Self Destruct seems to be to destroy the base and to destroy [[The Sleeper]]
- Large amounts of the base are already damaged
- See a drilling area and Braincase room
- Debate to release the Self Destruct but Paul argues we don't have enough information to do that 
- Go check out the drilling
- See setup that would pump silver fluid into the drills and new drills that would pump out vile liquid
- Paul feels the drills, but no bad reaction
- Go to Braincase room
- Smells like rotting brains
- See metal canisters that [[Caduceus]] asked us to look for.
	- Liquid with crystal in them
- Amandus hears whispering in [[Naacal]] that the Self Destruct has been paused
	- Thinks the brains are the cause of it being paused
- Paul detaches one of the metal canisters
- Hear over speaker "Self Destruct in 15 Minutes"

##### Navigation
[[Session 23 - Iceland]] | [[Two-Headed Serpent]] | [[Session 25 - Iceland]]

