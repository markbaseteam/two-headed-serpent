---
sessiondate: 2022-11-07
sessionyear: 2022
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 25 - Iceland
**Date:** 2022-11-07

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Max Tannenbaum]]
- [[Paul Schreiber]]

## Events

Overhear someone say something about us helping [[Caduceus]] destroy humanity. They are evacuating. To the dripping lava! [[Amandus Winston Steel|Amandus]] runs across likes its No Mans Land. Come across some room with stone statue - looks like stone serum on people. Yeah. Sanity Loss. Amandus tosses a grenade and moves on. Gloating, taunting they (serpents) are all going die. 

Well, we will see if we get out. Madness is not helping us. [[Hugo Gustafsson|Hugo]] see the spheres being filled with liquid. [[Paul Schreiber|Paul]] goes even more mad, but learns way too much about Cthulhu Mythos and [[Naacal]]. Paul has lost control of hirnself as he is connected to nearly every mind in the facility (braincase network). [[Mi-Go]] created it. Paul thinks he is a Mi-Go Engineer. But the serpents made him get into a braincase. This form is bizarre, but serviceable. 

Stupid babies, ignore me. Well, then one comes up and injects him with this stone stuff (-55 Dex! Turning to stone). [[Amandus Winston Steel|Amandus]] leaves him grenade and limps away. 

[[Mi-Go]] Engineer. 

Looking to escape in the pods. [[Joseph Laird|Joseph]] fled on foot. Many rocks and lava, but we come shooting out of the top of the volcano. Capybaras are safe, Joseph presume lost until [[Hugo Gustafsson|Hugo]] sees him. 

Then there are hill sized hands trying to erupt from the ground. This might be the whole peninsula. Finally [[Amandus Winston Steel|Amandus]] sees [[Joseph Laird|Joseph]]. Amandus heroically saves him. [[Paul Schreiber|Paul]], well he is space. 

“Thar she blows!” 

Use the pod to go to NY. Go to [[Joseph Laird|Joseph's]] mansion. 

Skill/Sanity Refresh. 

### Evening of May 10, 1933 - Wed (night of our arrival in Iceland). 

Note from the mob that they found something terrible at the [[Red Hook warehouse]].

[[Amandus Winston Steel|Amandus]] girlfriend looking for shelter. 

##### Navigation
[[Session 24 - Iceland]] | [[Two-Headed Serpent]] | [[Session 26 - New York]]

