---
sessiondate: 2022-11-21
sessionyear: 2022
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 26 - New York
**Date:** 2022-11-21

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Paul Schreiber]]
- [[Clara Boyce]]

## Events

[[Amandus Winston Steel|Amandus]], steady as a rock. Retroactive Spot Hidden - some of the screens in the transportation room. Map of the world with an image with areas blowing up. Some were where we had been. Most with Volcanos.

[[Clara Boyce|Dr. Clara Boyce]].

“It was like that when we found it” (re Iceland [[Amandus Winston Steel|Amandus]])

Arnandus - no dream - hard to sleep.

[[Hugo Gustafsson|Hugo]] - Dream with [[The Queen]] - [[Yig]] was mere mortal - should worship a real [[Ghatanothoa|dark god]]. They seem to be using [[Mu]] to dominate humans. Queen needs [[Cobra Crown|crown]] and [[Serpent Scepter|scepter]] to thwart them. They were Muuuuuuved. Hahahaha! They might be trying to use a drug to clear the mind.

[[Amandus Winston Steel|Amandus]] - more scales - under right hand. Look in mirror more underlying scales. Uglier, but tougher.

Paper -
- That OK town ([[Oklahoma Briefing|Bingham]]) had a breakout of Polio - total lockdown.
- Lots of disasters.

[[Paul Schreiber|Paul]] will modify the flamers for our use. He has plans in the city and takes one of the cars. [[Amandus Winston Steel|Amandus]] looks to go into town to retrieve [[Capy]] and his GF [[Dr. Julia Smith]].

[[Hugo Gustafsson|Hugo]] and [[Joseph Laird|Joseph]] to see [[Bonanno Family|The Mob]] about what happened at the [[Red Hook warehouse]].

During this time, [[Clara Boyce|Clara]] works with [[Dr. Julia Smith|Dr. Smith]]. Things get more and more weird at [[Caduceus]], and people have been disappearing. She is plotting her exit. Bad things in the lab.

**Some papers **
- [[Update on the Activies of the Inner Night]]
- [[Update on the Activies of the Dreamer]]
- [[Summary of Research on the Cobra Crown]]
- [[Mission Update Iha da Queimada Grande]]
- [[Research on the Facilities Available at the Citadel]]

Yikes, the Queen is a Sith - Darth [[The Queen|Tyranissh]]. Worships [[Ghatanothoa]]. [[Cobra Crown]] and [[the Citadel]]. [[Sashinal]] in conflict with both. Calcutta.

[[Amandus Winston Steel|Amandus]] meets [[Dr. Julia Smith|Dr. Smith]] and [[Clara Boyce|Boyce]], and bring them to the Mansion with [[Capy]]. [[Caduceus]] did help her family and a village. 

##### Navigation
[[Session 25 - Iceland]] | [[Two-Headed Serpent]] | [[Session 27 - New York]]

