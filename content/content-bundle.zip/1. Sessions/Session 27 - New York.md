---
sessiondate: 2022-11-28
sessionyear: 2022
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 27 - New York
**Date:** 2022-11-28

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Paul Schreiber]]
- [[Clara Boyce]]

## Events

[[Paul Schreiber|Paul]] overhears info about that serum over speaking stone. Mob person involved. Seems like everyone is against us. [[Sashinal|Rose Meadham]] speaks. Then a note that more people than normal into the basement. Troublesome operatives leaking information. 

[[Hugo Gustafsson|Hugo]] and [[Joseph Laird|Joseph]] meet the mob ([[Giovonni Bonventre|Uncle John]]) at 11 at [[Casa Oliva]]. [[Francesco Garofalo|Fancesco "Frank Caroll" Garofalo]], underboss. 

Mob - situation escalated. 40 Men found dead in an room (safe house). Greetings from [[Joshua Meadham|Meadham]] (head of [[Caduceus]]). All stabbed to death. Maybe smallpox. Oh a small box. 

Two hand sized sketters ([[Hugo Gustafsson|Hugo]] freaks as this is his recurring dream (death of wife). [[Giovonni Bonventre|Uncle John]] taken by [[Caduceus]] to the main basement of the [[Caduceus Building]]. 

Looking for 
- “Giovani “[[Giovonni Bonventre|Uncle John]]” Bonventre - Caporegime is missing in the [[Caduceus]] basement. 
- [[Martino Bresciani]] - Caporegime 

Meanwhile [[Amandus Winston Steel|Amandus]] tells everything to [[Clara Boyce|Clara]], causing 4 sanity points. 

[[Paul Schreiber|Paul]] looks at the Skeeter. Something made this to deliver a nasty drug. Drains intellect. 

Might be a good number of innocents behind the door in the basement. 

On fixing [[Amandus Winston Steel|Amandus]] rock issue - [[Paul Schreiber|Paul]] and [[Clara Boyce|Clara]] figure out something that will work. Intense pain as the rocky stuff changes during the evening. Dream dark warrens - setting lighting - the Queen is walking away. There are Neeps around. Whispers, we could have helped you. Rejected. Now with other girl. Now a bunch of Brits, Glowing eyes - but not people. Not a dream from [[the Queen]]. 

Burning recedes. More black scales with occasional red like a cobra. 

Note: big party at the [[Caduceus]] building (Mayor/etc). 

The team is leaning on blowing up the [[Caduceus Building]].

[[Joseph Laird|Joseph]] gets a mob call for big chickens. We go to [[Casa Oliva]]. Closed except [[Francesco Garofalo|Frank Carol]] and goons are there. Looks like they found the mole. [[Martino Bresciani]] - not he is not blinking or sweating. This might be [[Mob Team Leader|the voice]] over the talking stone [[Paul Schreiber|Paul]] overheard. He is surprised by the voice statement. 

[[Amandus Winston Steel|Amandus]] punches him in the face. His skin breaks and he becomes very scaly. Some sanity checks by [[Bonanno Family|the Mob]] and [[Clara Boyce|Clara]]. [[Martino Bresciani|Bresciani]] ([[Inner Night]]) wants to offer a deal. 

Once we do not deal. it starts to chant to become black goo. We kill him before he can accomplish it [[Clara Boyce|Clara]] nearly goes insane after the last few days. Note that one of the mob working with the traitor is blowing up the building. Yet again, we are in a situation where something is about to blow up. 

Arrive at the building - Cliffhanger! 

##### Navigation
[[Session 26 - New York]] | [[Two-Headed Serpent]] | [[Session 28 - New York]]

