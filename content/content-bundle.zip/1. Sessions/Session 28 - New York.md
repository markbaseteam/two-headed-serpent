---
sessiondate: 2023-01-09
sessionyear: 2023
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
%%
RPGGeek Link: [https://rpggeek.com/rpgitem/220159/two-headed-serpent](https://rpggeek.com/rpgitem/220159/two-headed-serpent)
%%
# Session 28 - New York
**Date:** 2023-01-09

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Paul Schreiber]]
- [[Clara Boyce]]

## Events
We arrive timely, again! Famous people around. 

There is a mobster keeping watch - demo specialist ([[Vernere Ardito]]). There is a truck with [[Caduceus]] logo about 4 - 5 blocks away. The actual cleaning people are tied up in the van. There are two uniforms. 

[[Amandus Winston Steel|Amandus]] tries to sneak up on the mobster, but Amanda cheats. The guy hits the horn, then tries to run. [[Hugo Gustafsson|Hugo]] tries to follow...crit fail. 

[[Joseph Laird|Joseph]] determines we have about 30 minutes. Meanwhile [[Clara Boyce|Clara]] chats up a cop to keep them away. 

Into the building, servant entrance. [[Paul Schreiber|Paul]] and Clara look for a fire alarm to get people out. Hugo, Joseph, and Amandus look for where there might be bombs. Come upon one of the people planting bombs. Arnandus sneaks up and subdues him finds out more information. 20 Minutes. 

Fire alarm goes off. Guards come. Paul crit convinces the guards to go go go. We clear the bombs, other team is in the sub-basement. Get into an area there there are desecrations. Nasty stuff. 

Found people in cages. Found a lot of my ex-girlfriends ([[Sashinal|Rose Meadham]] in many deformed states. 

- So either the head guy was trying to get his daughter back 
- Or the Night had other control does here. 

We chase after Clara. 

But we find a room....gas. Bloody Germans. 

End of chapter... like off to Snake Island.

##### Navigation
[[Session 27 - New York]] | [[Two-Headed Serpent]] | [[Session 29 - Belgian Congo]]

