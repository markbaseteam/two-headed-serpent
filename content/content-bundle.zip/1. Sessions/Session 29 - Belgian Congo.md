---
sessiondate: 2023-01-23
sessionyear: 2023
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 29 - Belgian Congo
**Date:** 2023-01-23

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Paul Schreiber]]
- [[Clara Boyce]]

## Events

So we wake up and have sheets over us. like stored furniture. We are in Belgian Congo. Our plane crashed, sent by [[Caduceus]]. Are by the diamond mine. [[Amandus Winston Steel|Amandus]] tires to punch her in the face. She dodges, guiltily. 

Nurse [[Fleurette Tetrault]]. if that is her real name. She gets the doctor. We do not have our gear. We are in scrubs. One set of clothes. They claim some sleeping sickness. We are the first to recover. Tetse flies with the sickness. 

![](https://i.imgur.com/lWKCOfa.png)

Claims to work for the mining company Forminiere. [[Caduceus]] sent to help us.  

(full name [[Societe Internationale Foretiere et Miniere du Congo]])  

### May l3, 1933  

That is not two weeks plus flight time. Only felling a peckish. Amandus finds a mic in the wall, and tells them we are coming for you. Hugo “says” that we got caught by [[Inner Night]]. [[Dr. Mason Thibualt]]

Dr is back. Sorne drink the water. Arnandus has the Dr come over and look as this scales. He does not even notice it. [[Clara Boyce|Clara]] notes that he cannot see it. Clara tries to force.

So Arnandus goes all into the stories. Clara convinces him to let her she his psyche notes.  

**Handout Sleeping Sickness**
![](https://i.imgur.com/V449nWu.png)

They claim our stuff was not recoverable from the wreckage.  

![](https://i.imgur.com/SaqCMGu.png)

**Ulunga Village**
![](https://i.imgur.com/bowBkYH.png)

The other crew go into the village. Meet some [[Professor Carole Roux|explorers]], [[Manville Garreau|one]] with a elephant gun. They lost most of their crew, and talk of dinosaurs. 

Tea time. The Dr keeps doing the same experiment over and over, and it fails. He thinks its the same. Strong whiff of raspberry. One of the nurses brings it in. Clara is messing with him. 

That one nurse is the problem. Nurse [[Melania De Vooght]] (evil). Diamond mine closed a year ago.  

Various conversations point to the diamond mine.  

[[Kasongo Odia]] - the kilolo (village chief) fisherman  

Nurse [[Melania De Vooght]] - Button  

Nurse [[Geertryud Van Lacre]] lighting light gun. Amandus dodges, then runs after her. Slashes with a scaple . small amount of damage. She is kinda snakey. 

There are flies swarming in the village. They find some box that is emitting the swarms. [[Paul Schreiber|Paul]] looks to burn them with gasoline. [[Joseph Laird|Joseph]] opens a safe and finds documents, including in [[Naacal]]. 

Chase her into the jungle. She is fast. She runs towards some exotic flower, but it emits a high pitched whistle. Having lost ground, Arnandus goes to the flower and it emits the sound again. Amandus realizes that he would not have heard it prior to his enhancements. 

Later Clare misreads some bad Naacal, like double fumble. Looking to destroy evidence. They find the real radio. 

Amandus notices more of these flowers, grid like pattern. But something sneaks up on me. A dinosaur

![](https://i.imgur.com/PTcTeni.png)

##### Navigation
[[Session 28 - New York]] | [[Two-Headed Serpent]] | [[Session 30 - Belgian Congo]]

