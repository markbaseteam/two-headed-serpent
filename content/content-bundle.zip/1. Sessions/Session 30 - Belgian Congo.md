---
sessiondate: 2023-02-06
sessionyear: 2023
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 30 - Belgian Congo
**Date:** 2023-02-06

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Paul Schreiber]]
- [[Clara Boyce]]

## Events

Luck refresh.

**Caduceus Congo Map**
![](https://i.imgur.com/P97ndM4.png)

Remembering his WW1 days, you jump on tanks to beat them. [[Amandus Winston Steel|Amandus]] runs up the ridge, leaps. and collides with the rider. They are in an epic pulp struggle to win control of the dinosaur. The [[Serpent Race|serpent folk]] snaps at Amandus and missing with its fangs. The T-Rex tries to shake Amandus off. but he is well ensconced.

The others arrive. [[Joseph Laird|Joseph]] comes rushing in from the Jungle and pokes the T-Rex with a spear. annoying it. [[Manville Garreau|Manville]] pulls out the Elephant Gun, actually damaging it.

Amandus with mighty punch both separates the helm from the serpents head, and sends him flying off the dinosaur. The T-Rex is eyeing the serpentman. and the helm is near Joseph. Amandus yells to grab it.

[[Hugo Gustafsson|Hugo]] grabs the rod and puts on the helmet. [[Professor Carole Roux]] shoots at the T-Rex, but its a mere annoyance. The Serpent Person rushes Hugo, but is not able to grab the helmet. The T-Rex lurches towards the Serpentman and misses, but sends Amandus flying.

[[Clara Boyce|Clara]] goes on a rage and cuts up the serpent person. Hugo fails to think dinosaur thoughts and gives the helmet to [[Paul Schreiber|Paul]]. Paul manages to think a few dinosaur thoughts. Manville seems dead set on killing the dinosaur.

We cannot get it under control, and probably will have to put it down. But we hear more T-Rex’s off in the distance. Hugo slays the newly endangered species with the staff.

Petty Amanda bites Amandus with a bug after defeating her mighty dinosaur. 

### To the Diamond Mine.

Well, first back to the camp for water, and get our wits about us. Try to get the radio working, but too much serpent tech woven into it. Gather supplies and prep, go the next morning. T-Rex tastes like chicken, We take the [[Kasongo Odia|chief]].

#### May l4, 1933

One of those flowers - high pitched sound. It Crimson Nirnroot! Its about 2’ tall. Then see the grid. Then hear Rexs. And a few Germans. The mine is fenced off - barbed wire. Gate is chained shut See an abandoned building.

Joseph scoffs at the lock with contempt and we go in. There is movement at the bottom of the pit. Well, well, well, there is a pyramid. Many people wonder aimlessly and drinking our of troughs.

![](https://i.imgur.com/L3KLxx7.png)

The [[Richard Clemons|geologist]] from North Borneo is ~~yelling for us to get out~~ there. And [[Pearl Schoenbaum|Pearl]], the skin shedding lady, is down there (Amandus). Some of the kids. We seemed to see people we know, but all different A bit sanity impacting.

##### Navigation
[[Session 29 - Belgian Congo]] | [[Two-Headed Serpent]] | [[Session 31 - Belgian Congo]]

