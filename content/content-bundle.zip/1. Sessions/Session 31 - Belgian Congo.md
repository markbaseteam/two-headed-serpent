---
sessiondate: 2023-02-20
sessionyear: 2023
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 31 - Belgian Congo
**Date:** 2023-02-20

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Paul Schreiber]]
- [[Clara Boyce]]

## Events

Amandus is feeling feverish and down 5 points of Int. Might be turning into a snake. We go to a lift and go down using some advance tech. Have to use a small prick to get in. (bad Amanda)

**Diamond Mine**
![](https://i.imgur.com/fMXrpzJ.png)

### Inside the temple 

Wording in [[Naacal]] that Clara reads suspiciously well. Medical facilities, labs, records, room. And an Armory on the upper level. Working our way up to the armory. a door opens to a room of cells.

Two [[Serpent Race|serpent people]] with gold tubes. In the A large number of damaged Rose Meadhams. Amandus and [[Hugo Gustafsson|Hugo]] kill the two serpent people mooks before they can raise the alarm. There are two scientists. We intimidate them to find out what is going one. One blurts out that they might be trying to replace the Inner Night [[Sashinal|Rose Meadham]]  (the real one).

Ssulithan - [[Joshua Meadham]].

Are they making T-Rex’s? [[Joseph Laird|Joseph]] had a dream with too much insight. And there is a zombie army. Its the bug bites. But there is a cure at the top.

So its this:
- [[Caduceus]] - Enslave humanity 
- [[Inner Night]]- Destroy humanity

They are "processing everyone and closing the facility."

We move on. But Amanda makes us look in every room :). [[Clara Boyce|Clara]], who was on the edge, crit fails a Sanity roll. She really wants to learn more. This room has exposed brains - studying humans. But this room looks like one Joseph saw in a dream about his brother.

Next Room has large glass tubes. Swarms of mutated Tsetse Flies. Clara starts smashing. Clara has the strength of the mad and is unstoppable. Yet somehow Hugo holds her back from the "release" button.

Another room is full of vials. Hugo notes this is a bunch of stored DNA of plants and animals that are extinct. Jurassic park + Dreamland.

Up ahead is a T-Rex and a few serpent people coming out of a control room. Light beams hit us, severely injuring Amandus. Joseph blasts the one on the T-Rex. The helmet comes toward us and Amandus rushes to grab it. Clara blasts another one. Hugo takes out that last one, The T-Rex somehow gets the idea to eat one of us. Amandus dodges the huge jaw. then grabs the helmet.

Amandus now has a pet dinosaur. Time for a revenge tour. There is another room with a baby T-Rex.

##### Navigation
[[Session 30 - Belgian Congo]] | [[Two-Headed Serpent]] | [[Session 32 - Belgian Congo]]

