---
sessiondate: 2023-03-20
sessionyear: 2023
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 32 - Belgian Congo
**Date:** 2023-03-20

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Paul Schreiber]]

## Events

Amandus lets the T-rex eat the scientist. Moving on. Try to stealth, but Joseph makes a huge racket. Go by the records room - world map.  

### Records Room  

“To clear out for Calcutta trip” - note on a planning table. Hugo notes that the crown is likely in Calcutta. Joseph and Paul go in to find out more.  

We are attacked! By the nurses! But they miss! Amandus shoots Geertuyd, who turns out to be a red scaled serpent person. Chompy comes up and snaps at one of them. Geertudy shoots at Amandus but he dodges. Melania takes a bit of Chompy. Amandus shoots Geertudy again, and she collapses. Hugo burns himself. Paul shoots self, revealing puce. This is not helpful to his sanity. Chompy eats Melania.  

There is a bit of loot - a scalpel and a pouch. 6 syringes and sedative. And a vial that spells like raspberries.  

Joseph digs through the papers. Looks for his brother info and does find it! Its not good, but Joseph holds it together.  

Hugo studies the map - they are trying to dump these tetse flies in places to have the maximum effect. Grab everything.  

### Armory  

- Recover our stuff!  
- Green Vials labeled Antidote. They force Amandus to drink one even through he is just a bit sweaty.  
- Domination Serum (raspberry)  
- carotid toxin  

We gear up and take everything we can,  

### Basement!  

Huge glowing green portal thing. Other rooms with huge glowing rods. Chompy things its Alien. This triggers strange far off earth memories from Paul.  

Can set it up for a 5 minute delay and blow up everything in a 2 mile radius. Looks like we can set it to blow and get through the portal. Amandus is very sad - he has to leave Chompy behind. Set him free to feed. This sends us back into the NYC [[Caduceus Building]] near where we left.

##### Navigation
[[Session 31 - Belgian Congo]] | [[Two-Headed Serpent]] | [[Session 33 - New York]]

