---
sessiondate: 2023-03-27
sessionyear: 2023
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 33 - New York
**Date:** 2023-03-27

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Paul Schreiber]]
- [[Clara Boyce]]

## Events

Clara awakes! We close the portal blast doors. We are in the [[Sashinal|Rose Meadham's]] room before we passed out. Cautiously exit the building to regroup at Joseph’s estate. But the car is gone. so went the [[The Knox Club]].

### May 13. 1933
The mound of Papers:

**Research Summary**
![](https://i.imgur.com/MABBUDo.png)

**Article Treasure Show**
![](https://i.imgur.com/u161nvz.png)

**Handout - Personnel Files**
![](https://i.imgur.com/SNgdmNp.png)

[[Research on the Facilities Available at the Citadel]]
[[Update on the Activies of the Inner Night]]

**On [[Thaddeus Laird|Joseph’s Brother]]**
![](https://i.imgur.com/XTJbXjo.png)

They left on the 12th for Calcutta

Rest for a bit then the dreams...

Hugo - [[The Queen]] asks if we are joining her in Calcutta. She is close to [[Cobra Crown|the Crown]]. She is all about the lord of the volcano. [[Mu]] is out of sync with reality. [[Inner Night]] is trying to bring it back. But bad things would happen. The sudden appearance of a continent in the middle of the Atlantic Ocean would be disruptive.

Decide to rest up while making the spheres operable.

Raid [[Caduceus Building]] for lab stuff and anything interesting that we can find. Go up to seven to try to get the elevator. [[Amandus Winston Steel|Amandus]] gets caught but intimidates the guard (hell of a roll). Get him talking. Lab equipment send to Brazil. Iha da Queimada Grande.

Guy is now a buddy. Get into elevator and up to 17, trying for 18. Hugo succeeds. Rifle the place.

- [[Book of Eibon]] - English translation, 15th century 
- A copy of a pamphlet of notes on the [[Zanthu Tablets]]

[[Mission Update Iha da Queimada Grande]]

There is a safe, but it goes badly. It opens, but there is a strange screech alarm. Get in the elevator, but we will have to stop the elevator, climb on
top and send it on its way. We climb up out a vent shaft and escape the building.

There are spellooks and [[Extracts from the R'lyeh Text]] .

##### Navigation
[[Session 32 - Belgian Congo]] | [[Two-Headed Serpent]] | [[Session 34 - New York]]
