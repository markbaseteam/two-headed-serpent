---
sessiondate: 2023-04-17
sessionyear: 2023
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 34 - New York
**Date:** 2023-04-17

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Paul Schreiber]]
- [[Clara Boyce]]

## Events

We read the books....Paul cracks. Temporary Amnesia.
- [[Extracts from the R'lyeh Text]] 
- [[Book of Eibon]]
- [[Zanthu Tablets]]

[[Serpents of Mu]] - big weapon to wipe everyone out and hide below.

Another Group just phased out [[Mu]], creating the ledgend of Atlantis.

Portal in the [[Caduceus Building|Meadham Building]]. Also Iha da Queimada Grande in Brazil.

And spells!
- Paul learns [[Grasp of Cthulhu]]

Amandus Researches Calcutta
- [[Great Eastern Hotel]] - we book, probably where [[Joshua Meadham]] will be staying
- Grand Hotel - OK
- Bristol - Slum
- Dalhousie Square - center of British colonial admin, includes post office, town hall, and telegraph office
- Hooghly River - big river that goes through calcutta
- Very hot and humid. 73-104 F. humid and sticky. nearly monsoon season
- Great Museum - Include Rasputin Meteorite from the Siberian Strike
	- Head Curator Mr. [[Vatsala Kumtekar]]

**Calcutta - Handout - Article Treasure Show**
![](https://imgur.com/u161nvz.png)

Josephs Cracks - Now covets neighbor's art. Wakes up with it.

The Files - They have been suspicious of us, and consider expendable. They did infect Amandus and Paul to be human/serpent hybrids.
![](https://imgur.com/SNgdmNp.png)

Note: Anyone that looks at [[Ghatanothoa]] is tuned to stone.

More dynamite.

May 21, 1933 - Departure 

##### Navigation
[[Session 33 - New York]] | [[Two-Headed Serpent]] | [[Session 35 - Calcutta]]

