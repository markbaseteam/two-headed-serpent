---
sessiondate: 2023-05-15
sessionyear: 2023
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 35 - Calcutta
**Date:** 2023-05-15

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Paul Schreiber]]
- [[Clara Boyce]]

## Events
Arrive in Calcutta at night. Hotel has flat roof. We land stealthily. Just down the way, there is a massive traffic accident involving a white person. A  policeman seems to stash as crown. There is a large car that stops at the Great Eastern Hotel, a veiled woman talks with 2 goons.  

Working our way down the stairs, we hear a crash of a door a few floors down. Room 403. Cambridge explorers. [[Jonathon Taylor]] and [[Tulsidas  Vikniatji]]. Some to the tea room at 4 every day.  

Get checked in - 6 rooms just cuz. There is a tea room/pace to eat (Willards Tea Room). 6th floor (601-606. 603 the meeting room). Amandus picks up  
[[Naacal]]. "Is that the [[Caduceus]] team from Iceland? I thought they were dead."

Joseph tracks them to the Grand Hotel. There is a crown, the veiled lady, and a [[Haftorang device|star device]] (big bomb that blew up the mountain).  

**Veiled Woman**
![](https://i.imgur.com/NiZZ5Gx.png)

**Rose Meadham**
![](https://i.imgur.com/nD9eBtz.png)

Back at the hotel. Clara notices important people ... and fumbles. Now stuck as a bellhop - a bad bellhop. Names get dropped.  

Paul learns another spell.  

Back at our hotel. Joseph investigates the room with the fake crowns. Finds a couple. and a few items.  

**Calcutta Handout Pocket Objects**
![](https://i.imgur.com/9u5XwoK.png)

The copies are too good - someone making the copies has the original.  

Next morning, a note for a meeting. "Meet at noon at Dalhausie Square - A friend." The square is the center of British administration. Letter E on Map.  

![](https://i.imgur.com/kVSNcP9.png)

Clara wants to call British Museum. Go down the stairs. [[Joshua Meadham|Meadham]] and goons interrogating a Bellhop, looking for our party. They see us and cock a gun.  

Cliffhanger!

##### Navigation
[[Session 34 - New York]] | [[Two-Headed Serpent]] | [[Session 36 - Calcutta]]

