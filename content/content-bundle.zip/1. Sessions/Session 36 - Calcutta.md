---
sessiondate: 2023-06-12
sessionyear: 2023
campaign: "Two-Headed Serpent"
tags: session, SerpentSession
setting: Cthulhu
summary: 
---
# Session 36 - Calcutta
**Date:** 2023-06-12

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Paul Schreiber]]
- [[Clara Boyce]]

## Events

![](https://i.imgur.com/zFtOdzf.png)
![](https://i.imgur.com/VEjW0ph.png)

They shoot up the lobby. Amandus headshots [[Joshua Meadham|Meadham]], who is suddenly incredibly fast, revealing red scales but is not injured anywhere near enough. Amandus shuts the door end pulls Clara to run. [[Canning]] pulls the door off it hinges with a massive tongue (a bit of sanity loss for Clara).

Clara is not keeping it together. Long Tongue Phobia. She flees up the stairs in high heels.

A chase breaks out. Amandus leads them to the 4th floor, headed for 403. Goons spray and pray. Meadham shouts to get them. Meadham splits them between us and the rooms on the 6th. Joseph sets up an ambush in 603 (the meeting room). Paul casts a spell that summons fog.

Amandus crashes through door 403, sends Clara up the fire escape, steps out to the fire escape and readies to shoot the first goon that comes through the door. Paul pulls off the Power, filling the hallway with fog. That does have a minor impact (sanity) on Hugo and Joseph as they have never seen such magic. The goons burst in and Hugo and Joseph fire. A goon is obliterated by a fire weapon from Hugo.

Canning fills the doorway. Amandus fires to no effect, grabs Clara's hand and pounds up the fire escape. Its tongue lashes out but just misses Amandus. "Get the grenades!" he shouts. Only Paul hears what is going on outside. Paul gets the window open, Hugo gets the flamer ready, and Joseph readies dynamite. Clara and Amandus dive into 603.

Canning keeps come up, with his long tongue out. Paul casts Grasp of Cthulhu, burns lots of Luck to pull off the power. The power goes off, but Canning grabs the tentacle and tosses it aside. This messes Paul up quite a bit - he starts monologuing and gloating. Amandus goes for his shotgun, Joseph goes to blow up the fire escape. Hugo goes back to his room for weapons, and Clara follows Amandus for weapons as well. Two Goons and Meadham are getting onto the staircase as well. Joseph drops the dynamite (with Luck) and blows up the fire escape. A bit of blowback on Paul and loseph.

This obliterates Canning, Meadham, and the goons. Canning and Meadham are serpent people. To the roof!

To the Fairlawn! Joseph checks us in under false names. How are they going to find us so we can take them out?

Paul overhears someone in a nearby phone booth. Noted he was attacked and he is trying to get out of the company.

(aside, we heal a bit, but Paul now has a fangs growing in with more scales).

##### Navigation
[[Session 35 - Calcutta]] | [[Two-Headed Serpent]] | [[Session 37 - Calcutta]]

