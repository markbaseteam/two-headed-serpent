---
sessiondate: 2023-06-26
sessionyear: 2023
campaign: "Two-Headed Serpent"
tags: session, SerpentSession, nolog
setting: Cthulhu
summary: 
---
# Session 37 - Calcutta
**Date:** 2023-06-26

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Paul Schreiber]]
- [[Clara Boyce]]

## Events
**Note: Paul's fangs are prominent.**

The man in the phone booth looks Indian and is dressed as such, but is not comfortable in the outfit. His is trying to get out of the country. He has the Artifact.

Wants an advance to get passage.

Amandus charms the quy to come with us. We got the 8th floor since our flying spheres are up there. [[Tulsidas Vikmatji]]. [[Jonathon Taylor]] is dead. They made the copies. They tries to set up sales, but a bunch of bad events. Wants to go back to London as he contacts with the British Museum.

Bargain to get the crown in exchange for a plane ticket. To the Temple of Mansa Dev. It's a mess - many injured and dead. We split up - some to the basement, some to find out what is happening. They were betrayed by a member - and left with the artifact. Basement has bodies but no crown. An old man crawls towards us - his skin is gray. Someone (else) accuses the old man of bringing death. His hand dissolves into dirt - he just falls apart. Dying word - "she took my face"

Hugo hears a voice that morphs into [[The Queen|Tyranissh]], the Queen. He goes out into the street to investigate, amid the pain and squelching. Hugo sees her on a wall with a giant beam of light. Crowd gathering. The people are merging. It makes 6 different creatures. Giant lizards screaming. And oh, she has the crown. This did not work as she would like. She turns one of the creatures and jumps on it to fly away. Some of these creatures become Kaiu and start rampaging

Clara cannot handle this scene. Amandus does not really react - he has seen worse in the Great War. She flees. We decide to flee as well.

We happen to be going to the square with the noon meeting. Decide to go to the hotel and get the spheres then come to the meeting. Joseph and Hugo go to meet and the rest of us provide air cover. Its one of the men that Joseph followed to [[Sashinal|Rose Meadham]]. Has a envelope and a box - likely [[Haftorang device|the bomb]]. Likely a serpent person. He puts the items down and leaves. The bomb is the 5-mile radius version, not armed.

Two letters.

Left us the means to destroy [[Caduceus]]. The gates are unguarded. Common enemy. Includes a summary of what they think is going on ([[Inner Night]]).

British - Rocket Launchers!?!?

We fly up to active the serpect [[Serpent Scepter|Staff]] and hope it works on the Kaiju. We hope to lure the creatures out and blow them up, then go to Snake Island off Brazil. Hugo spends huge amount luck to influence them. British blow up 2 of them, we lure them out and Joseph sets off the bomb.

Off to Snake Island, which is know to be packed with snakes.

##### Navigation
[[Session 36 - Calcutta]] | [[Two-Headed Serpent]] | [[Session 38 - Calcutta to Snake Island]]

