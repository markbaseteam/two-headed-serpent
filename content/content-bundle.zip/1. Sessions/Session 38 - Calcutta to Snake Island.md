---
sessiondate: 2023-07-10
sessionyear: 2023
campaign: "Two-Headed Serpent"
tags: session, SerpentSession, nolog
setting: Cthulhu
summary: 
---
# Session 38 - Calcutta to Snake Island
**Date:** 2023-07-10

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Paul Schreiber]]
- [[Clara Boyce]]

## Events
Image: 07 Snake Island - Handout - Map
Image: 07 Snake Island - Image - Sea Serpent

Paul gets a sense of what was going on back in India. Tyranissh the Queen was trying to bring something through a gate but something was interfering. An entity threw off where she wanted to target the gate. The entity was not hostile to her, however. This is similar to the one in North Borneo. It likely was targeting Mu. She might be going to Snake Island as the gate there might not be impacted by the Entity.

Sleep is tough. More volcanos. And alien dolls with a trapped god. Back to the weird lost painting - mob are mushed into giant Kaiju. Dr. Julia Smith - skin is back to rock. Julia is partially transformed - veins and eyes black. Multiple eyes. Goo. She is talking to first love. She is partially transformed. Weird legs. She has fangs.

She holding a bone with a dried meat. Clara's sister - more madness and fired.

We stop off in Rio to party and confer. Amandus and Clara party a bit too hard to cover the screams in their dreams. Hugo and Joseph look for explosives, including 2 anti-personnel mines.

More dreams. Amandus and Clara hold it together.

Clara pisses off the locals trying to fine anti-venom. But pushes with First Aid and pulls it off.

Snake Island!

After some prep, we go to the island. We get there at night. Clara spots several things. A storm front. No moon. The beach is not far from the lighthouse. But the lighthouse throws off vision. But Hugo navigates it with ease to land near the lighthouse. But something large is reaching out of the water at us. Hugo and Amandus dodge with ease. But Paul does not. A huge sea serpent lunges out. Amandus and Paul are not effected, but the others have a drain on sanity. Clara is in bad shape. Paul gets knock around but maintains control. His sphere will need repair. Amandus avoids the tail easily but Hugo's sphere takes a hit. The sphere takes a hard hit, cracking it. He is now floating in the pounding surf.

Amandus and Joseph land near the lighthouse, where there is there something gate-light, flickering. Amandus and Joseph nod, and decide to try to ram it. It does smash the controls. The gate is going to explode. The snake person looks to flee. Joseph and Amandus put the lighthouse between them and the gate as they flee. The others flee as well. The serpent person is with us. The explosion is painful, but the gate collapses.

Hugo is not happy with Amandus.

There is an explosion wave out to sea - Mu moves differently. Something massive has appeared in the sea. Likely a tsunami on the way.
##### Navigation
[[Session 37 - Calcutta]] | [[Two-Headed Serpent]] | [[Session 39 - Snake Island]]

