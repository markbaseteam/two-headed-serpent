---
sessiondate: 2023-08-07
sessionyear: 2023
campaign: "Two-Headed Serpent"
tags: session, SerpentSession, nolog
setting: Cthulhu
summary: 
---
# Session 39 - Snake Island
**Date:** 2023-08-07

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Paul Schreiber]]
- [[Clara Boyce]]

## Events
Image: 08 Mu - Image - Arrival
Image: 08 Mu - Image - Battle

Paul and Hugo get the spheres operable. Amandus gets Clara past here mania. Into the spheres. We shoot straight up, and there is a giant ray of light out to sea. The wave washes over the island and continues onto the mainland. He head towards the emerging Mu.

Off in the distance, we hear the sounds of battle. There are giant bat things off the distance. Diving into some clouds, they creatures do not see us and they move on. Arriving at the island, there is a large volcano with structures on top. The land is prehistoric, if not alien. There is an active battle near the structures.

During this massive battle, its clear that Mu is not fully in phased. Its an ugly battle. This reminds Amandus of the Great War. Paul does not handle it so well. He takes the Sphere in, to find "the answers." Hugo follows in his sphere.

Try to get this remote some creature is using. Move on, into this weird place structure.

##### Navigation
[[Session 38 - Calcutta to Snake Island]] | [[Two-Headed Serpent]] | TBD

