---
aliases: Amandus, Amandus'
tags: PCs
---
## Amandus Winston Steel
WW1 survivor and hired gun.