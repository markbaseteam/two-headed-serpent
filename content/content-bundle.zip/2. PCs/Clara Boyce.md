---
aliases: Clara, Dr. Clara Boyce, Boyce
tags: PCs
---
## Clara Boyce
A doctor with [[Caduceus]].  Friends with [[Dr. Julia Smith]].

![](https://i.imgur.com/4Y6zBB1.jpg)