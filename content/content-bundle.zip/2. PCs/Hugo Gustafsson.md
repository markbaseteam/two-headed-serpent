---
alias: Hugo, Hugo's
tags: PCs
---
## Hugo Gustafsson
Pilot in the Navy. 