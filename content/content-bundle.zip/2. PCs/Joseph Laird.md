---
aliases: Joseph, Joseph's
tags: PCs
---
## Joseph Laird
Retired bank robber.   His brother was a member of [[Caduceus]] and had tried to get him to join for years.  Joseph finally joined after [[Thaddeus Laird|Thaddeus]] died in the Belgian Congo.

[[Jeeves]] is the butler.

### Enemies
[[Charles Rome]] in mob in Oklahoma City.  Charles spent spent time in prison after a job went bad.

### Phobias
Large teeth after the encounter with the [[Dhole]]

### Dreams
[[Session 15 - New York|Dreamed]] he was in his [[Thaddeus Laird|brothers body]], dark cave. Some sort of medical procedure. Dinosaur head.

![](https://i.imgur.com/60QEnKV.jpg)