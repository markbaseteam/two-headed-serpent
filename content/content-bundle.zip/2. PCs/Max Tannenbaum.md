---
aliases: Max, Max's
tags: PCs
---
## Max Tannenbaum
The "Stitchman".  A mob doctor.  Connected to the [[Bonanno family]].