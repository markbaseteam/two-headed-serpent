---
aliases: Paul, Paul's
tags: PCs
---
## Paul Schreiber
Mechanical gizmos.