---
aliases: Caduceus Foundation, Caduceus'
tags: Groups
Faction: Caduceus
Summary: A charitable organization that secretly combats Mythos menaces.
cssclass: clean-embeds
---
## Caduceus
### History
In 1912, [[Joshua Meadham]] of New York City, founder of Meadham Pharmaceuticals, sold the business empire he had built up over the previous thirty years. This was a surprising move, as Meadham had a reputation as a cutthroat businessman, and no one who knew him could imagine him doing anything else with his life.

Meadham took the proceeds of the sale and founded a charitable organization to bring medical care to people affected by epidemics, natural disasters, and wars around the globe. He called this organization Caduceus, after the staff of Hermes. While many people incorrectly associate this symbol with medicine (because of its similarity to the rod of Asclepius), Meadham was perfectly aware of its more esoteric meanings.

While Caduceus carries out these charitable works, it has a more secret purpose. In his business dealings, Meadham had a few brushes with the Mythos, most notably in the form of serpent people trying to use the growing global trade in pharmaceuticals as a vehicle to interfere with humanity. Realizing that mankind faced dangers even greater than those Caduceus purports to deal with, Meadham has since used his considerable resources to seek out and combat Mythos menaces where he can, especially where serpent people are involved.

Most of those who work for Caduceus have no knowledge of anything beyond its surface mission. A smaller core team works on the true mission of Caduceus, using the guise of medical aid workers to gain access to dangerous places and carry out missions of assassination, sabotage, and subterfuge against Mythos targets, using the chaos of medical crises to cover their actions.

While it is possible for heroes to join Caduceus as uninitiated medical workers, they should become privy to the inner workings of Caduceus quickly. It may be preferable to bring them into the true mission immediately. Caduceus is always on the lookout for people who have had brushes with the Mythos to help in its work.

Even in its guise as a medical organization, the fact that Caduceus works in dangerous regions means a wide range of skills is required to support its cover operations, let alone its less public operations. An average Caduceus mission requires doctors, nurses, local experts, negotiators, researchers, armed guards, and people of questionable backgrounds to procure supplies through extra-legal channels. There are few hero professions that could not find some way of fitting into the organization.

### Locations
[[Caduceus Building]]

### Note
The organization, reach, and work of Caduceus are explored in greater detail in the Pulp Cthulhu campaign, *The Two-Headed Serpent*.