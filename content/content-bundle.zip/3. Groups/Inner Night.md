---
aliases: The Inner Night
tags: Groups
Faction: Inner Night
Summary: A splinter serpent person group who are worshipers of Tsathoggua.
---
## Inner Night
Worshipers of [[Tsathoggua]].
