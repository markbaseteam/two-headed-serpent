---
aliases:
tags: Groups
Faction: Yig
Summary: A cult of Yig in Bingham, Oklahoma.
---
## The First Church
A cult of [[Yig]] started by [[Reverend Kornfield]] in Bingham, Oklahoma.