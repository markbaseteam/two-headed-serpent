---
alias: Meadham Building
tags: Place
---
## Caduceus Building
### New York Headquarters
The main operations for [[Caduceus]] are based in the Meadham Building on Park Row, on the east side of Manhattan Island. It is currently one of the tallest buildings in New York City, at 18 stories, and is topped by a majestic dome structure and the American flag.

It is here that Caduceus organizes its operations, handles its finances, and carries out various research and training projects in secure laboratories. Security in the building is unusually tight, and most staff are not permitted access to the research laboratories in the lower basements, or the floors where the planning for missions in pursuit of the organization’s real goals takes place—including the top two floors, where Meadham and his inner circle have their offices. Armed security guards are on duty at all times, although most have no idea what Caduceus really is.

Despite this secrecy, most of the building is given over to the innocuous activities of Caduceus’ cover mission, and traveling around these floors will bring the heroes into contact with accountants, administrators, lawyers, procurement clerks, and various layers of management. The vast majority of these people have no idea that there is more to Caduceus than meets the eye, although some do have questions about the secure areas of the building, or some of the strange invoices and shipping manifests that end up on their desks.

#### Floors 7–8

Once the heroes have been told the true mission of the organization, they are given access to the 7th and 8th floors of the Meadham Building. This is where the real mission planning goes on, and there are walls covered with notes, clippings, maps, old books, and artists’ pads with odd diagrams in them. The team based here track the movements of various Mythos threats, trying to work out their schemes and how to stop them ahead of time. This work involves collating information from news sources and paid informants, as well as research into ancient texts and artifacts. Heroes talking to the staff here are just as likely to encounter people poached from military intelligence, newspaper offices, PI firms, and the halls of academia.

The offices are abuzz with activity, like a busy newsroom, with telephones going off constantly, people shouting questions and answers across the room, and impromptu meetings taking place around desks. The air is thick with cigarette smoke.

While most of the office is open-plan, the senior planners have offices, and there are a small number of meeting rooms. There is also a soundproofed room on the 8th floor where a small group of radio operators stays in touch with the various field teams.

The heroes are given a dedicated handler based here, named [[Dr. Victor Gomes Goncalves]]—a Brazilian medical doctor who has worked for Caduceus for 15 years and is part of Meadham’s trusted inner circle of advisors. He handles all briefings and debriefings and acts as a general point of contact for any requests the heroes may have for information, equipment, or funding.
