---
tags: Location 
---
An expensive hotel in Calcutta.