---
aliases: Mu's
tags: Location
---
## Mu
A place only reachable by one of the [[Serpent Race|Serpent People]] gates.