---
tags: Place
---
## Red Hook warehouse
A [[Caduceus]] warehouse in Red Hook.  Found evidence that the books are being altered.  A common shipment is dimethyl phthalate, an insect repellent.