---
tags: Place
---
## The Knox Club
A private club in New York.  [[Joseph Laird|Joseph]] is a member, as well as [[Giovonni Bonventre]].