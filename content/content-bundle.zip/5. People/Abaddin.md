---
aliases:
tags: NPCs
Faction: North Borneo Chartered Company
Role: Translator
Location: North Borneo
Status: Alive
---
## Abaddin
A translator in North Borneo.