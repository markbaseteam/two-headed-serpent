---
aliases:
tags: NPCs
Faction: Bolivian Aid
Role: Nurse
Location: Bolivia
Status: Alive
---
## Alaina
A nurse in Bolivia.