---
aliases:
tags: NPCs
Faction: Caduceus
Role: Secetary
Location: New York
Status: Alive
---
## Almeda McBurney
A secretary at [[Caduceus]].  Her purse was stolen by an urchin.