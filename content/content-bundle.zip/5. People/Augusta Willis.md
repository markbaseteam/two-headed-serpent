---
aliases:
tags: NPCs
Faction: Bingham
Role: Librarian
Location: Bingham
Status: Alive
---
## Augusta Willis
The librarian in Bingham.  Was against [[The First Church]].