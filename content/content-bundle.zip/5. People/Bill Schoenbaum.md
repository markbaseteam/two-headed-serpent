---
aliases: Bill
tags: NPCs
Faction: Bingham
Role: Blacksmith
Location: Bingham
Status: Alive
---
## Bill Schoenbaum
The blacksmith in Bingham.  Husband of [[Pearl Schoenbaum]] and father of [[Susie Schoenbaum]].  