---
aliases: 
tags: NPCs
Faction: Inner Night
Role: Operative 
Location: Unknown
Status: Unknown
---
## Caducius Team Leader
[[Inner Night]] operative assigned to watch [[Caduceus]].
