---
aliases:
tags: NPCs
Faction: Caduceus
Role: Manservant
Location: New York
Status: Alive
---
## Canning
[[Joshua Meadham|Joshua Meadham's]] Manservant and 7' goon.

![](https://i.imgur.com/VEjW0ph.png)