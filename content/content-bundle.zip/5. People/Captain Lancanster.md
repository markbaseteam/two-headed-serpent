---
aliases:
tags: NPCs
Faction: North Borneo Chartered Company
Role: British Military
Location: North Borneo
Status: Alive
---
## Captain Lancanster
Captain at the military base in North Borneo.