---
aliases:
tags: NPCs
Faction: Amandus
Role: Mascot
Location: New York
Status: Alive
---
## Capy
A capybara that [[Amandus Winston Steel|Amandus]] brought back from Bolivia.  Amandus brought him to the VA.