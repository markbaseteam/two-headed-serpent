---
aliases:
tags: NPCs
Faction: Joseph
Role: Mobster
Location: Oklahoma City
Status: Alive
---
## Charles Rome
An old acquaintance of [[Joseph Laird|Joseph's]].  He sent several years in prison after a botched job.