---
aliases:
tags: NPCs
Faction: The First Church
Role: Department Store Owner
Location: Bingham
Status: Alive
---
## Clea Butler
The owner of the Butler Department Store in Bingham.  She was bitten by a rattlesnake when [[Reverend Kornfield]] was shot.