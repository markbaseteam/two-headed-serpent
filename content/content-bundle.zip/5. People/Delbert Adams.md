---
aliases:
tags: NPCs
Faction: The First Church
Role: Hotel Owner
Location: Bingham
Status: Alive
---
## Delbert Adams
The owner of The Bingham Hotel with his wife, [[Rosemary Adams]].  He encouraged visitors to listen to the sermons of [[Reverend Kornfield]].