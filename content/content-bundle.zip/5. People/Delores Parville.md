---
aliases:
tags: NPCs
Faction: Caduceus
Role: Secetary
Location: New York
Status: Alive
---
## Delores Parville
[[Joshua Meadham|Joshua Meadham's]] secetary.