---
aliases: Arturo's
tags: NPCs
Faction: Caduceus
Role: Handler
Location: Bolivia
Status: Dead
---
## Dr. Arturo Ursini
A handler for [[Caduceus]].  He was killed shortly after meeting the group.