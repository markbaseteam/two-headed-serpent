---
aliases:
tags: NPCs
Faction: Bolivian Aid
Role: Doctor
Location: Bolivia
Status: Alive
---
## Dr. Gomez
A doctor in Bolivia.