---
aliases: Dr. Smith
tags: NPCs
Faction: Caduceus
Role: Amandus' girlfriend
Location: New York
Status: Alive
---
## Dr. Julia Smith
The doctor that helped with [[Amandus Winston Steel|Amandus']] recovery the operation to save him from [[Yellow Death]].
