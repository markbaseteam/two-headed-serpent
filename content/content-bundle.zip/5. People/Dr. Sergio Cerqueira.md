---
aliases: Dr. Cerqueira
tags: NPCs
Faction: Caduceus 
Role: Station Chief
Location: Brazil
Status: Unknown 
---
## Dr. Sergio Cerqueira
The [[Caduceus]] Station Chief in Santos, Brazil.