---
Aliases: Goncalves, Dr. Goncalves, Dr. Victor Goncalves
tags: NPCs
Faction: Caduceus
Role: Handler
Location: New York
Status: Alive
---
## Dr. Victor Gomes Goncalves
The group's handler with [[Caduceus]].  He is a worshiper of [[Yig]].