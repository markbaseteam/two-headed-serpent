---
aliases: 
tags: NPCs
Faction: Bingham
Role: Barber
Location: Bingham
Status: Alive
---
## Edith Kunkel
The co-owner of the barbershop in Bingham.  Her husband, [[Ralph Kunkel]], was healed by [[Reverend Kornfield|Rev Kornfield]].