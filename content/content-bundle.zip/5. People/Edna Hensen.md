---
aliases: 
tags: NPCs
Faction: Bingham
Role: 
Location: Bingham
Status: Alive
---
## Edna Hensen
Lives in Bingham with her husband, [[George Hensen|George]].  She was at the Deer Head Saloon and not happy about her husband sleeping under the house after being cured by [[Reverend Kornfield]].