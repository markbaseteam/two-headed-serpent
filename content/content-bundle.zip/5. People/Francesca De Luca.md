---
aliases:
tags: NPCs
Faction: Caduceus
Role: Security Chief
Location: New York
Status: Alive
---
## Francesca De Luca
[[Caduceus]] security chief. Near main entrance. Professional, pronounced widow's peak. She is more for the building.

She is a worshipper of [[Yig]].