---
aliases: Frank Carol
tags: NPCs
Faction: Bonanno Family 
Role: Underboss
Location: New York 
Status: Alive
---
## Francesco Garofalo
[[Giovonni Bonventre|Uncle John]] boss in the [[Bonanno Family]].