---
aliases: 
tags: NPCs
Faction: The First Church
Role: Lumbermill Worker
Location: Bingham
Status: Alive
---
## George Hensen
The husband of [[Edna Hensen]].  He lives under his house after being cured by [[Reverend Kornfield]].