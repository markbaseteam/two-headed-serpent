---
aliases:
tags: NPCs
Faction: Bolivian Aid
Role: Translator
Location: Bolivia
Status: 
---
## Gilmar the Translator
The local translator in Bolivia.