---
aliases: Uncle John, Giovonni
tags: NPCs
Faction: Bonanno Family
Role: Capo
Location: New York
Status: Alive
---
## Giovonni Bonventre
A mob boss with the [[Bonanno Family]].  Knows [[Joseph Laird|Joseph]] from his past life and [[Max Tannenbaum|Max]] from his current life. The uncle of the currnet head of the Bonanno Family.

Taken to the [[Caduceus Building]] basement after trying to infiltrate the [[Red Hook warehouse]].