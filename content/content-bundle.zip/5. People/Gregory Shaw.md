---
aliases: 
tags: NPCs
Faction: Bingham
Role: Mad Youngster
Location: Bingham
Status: Alive
---
## Gregory Shaw
Married to [[Peggy Shaw]] in Bingham.  People say their baby was cursed by [[Reverend Kornfield]].

He tried to burn down the church with [[Susie Schoenbaum]].
