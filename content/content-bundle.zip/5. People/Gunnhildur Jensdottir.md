---
aliases: Gunnhildur, Gunnhildur's
tags: NPCs
Faction: Iceland Aid
Role: Guide
Location: Iceland
Status: Alive
---
## Gunnhildur Jensdottir
A local Icelandic guide that was helping [[Caduceus]] with the evacuation from the Snaefellsjokull volcano.  Her brother is Ollie.
