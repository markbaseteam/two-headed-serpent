---
aliases: Old Harry
tags: NPCs
Faction: The First Church
Role: Barbershop Caretaker
Location: Bingham
Status: Alive
---
## Harry Mathewson
The caretaker of [[Ralph Kunkel|Ralph]] and [[Edith Kunkel|Edith's]] barbershop in Bingham.  He was healed by [[Reverend Kornfield]], but then ate a whole pig afterward.

He went with the [[Reverend Kornfield|Reverend]] to the place of his pilgrimage.  And led the [[Caduceus]] team there as well.

He was very uncomfortable after the [[Reverend Kornfield|Reverend]] was killed.
