---
aliases: 
tags: NPCs
Faction: Bingham
Role: Lumberyard Owner
Location: Bingham
Status: Alive
---
## Hilliard Fowler
The drunk owner of the lumberyard in Bingham.  He claimed [[Reverend Kornfield]] was cursed and shot him during one of the services.

[[Sheriff Benson]] shot him, but [[Amandus Winston Steel|Amandus]] saved him.