---
aliases: 
tags: NPCs
Faction: Joseph
Role: Butler
Location: New York
Status: Alive
---
## Jeeves
[[Joseph Laird|Joseph's]] butler at the country house.