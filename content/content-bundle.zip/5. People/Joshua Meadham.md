---
aliases: Meadham, Joshua Meadham's, Meadham's
tags: NPCs
Faction: Caduceus
Role: Leader
Location: New York
Status: Alive
---
## Joshua Meadham
The head of [[Caduceus]].  His daughter [[Sashinal|Rose]] was replaced by a serpent person at one point.