---
aliases: Meadham, Joshua Meadham's, Meadham's, Ssulithan
tags: NPCs
Faction: Caduceus
Role: Leader
Location: New York
Status: Alive
---
## Joshua Meadham
The head of [[Caduceus]].  His daughter [[Sashinal|Rose]] was replaced by a serpent person at one point.

Called Ssulithan by one of the [[Serpent Race|serpent people]] in the Belgian Congo.  

![](https://i.imgur.com/zFtOdzf.png)