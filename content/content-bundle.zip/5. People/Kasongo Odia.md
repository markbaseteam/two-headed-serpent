---
aliases: Kasongo
tags: NPCs
Faction: Ulunga
Role: Chief
Location: Belgian Congo 
Status: Alive
---
## Kasongo Odia

The chief of the village of Ulunga in the Belgian Congo.