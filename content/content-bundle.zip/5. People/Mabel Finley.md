---
aliases:
tags: NPCs
Faction: Caduceus
Role: Secetary
Location: New York
Status: Alive
---
## Mabel Finley
A secretary at [[Caduceus]].