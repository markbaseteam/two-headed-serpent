---
aliases: Manville
tags: NPCs
Faction: Unknown 
Role: Hunter
Location: Belgian Congo 
Status: Alive
---
## Manville Garreau

A big game hunter currently in the village of Ulunga.  He is working with [[Professor Carole Roux]].