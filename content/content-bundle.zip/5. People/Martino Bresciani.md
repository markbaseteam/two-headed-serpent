---
aliases: Bresciani
tags: NPCs
Faction: Bonanno Family
Role: Capo
Location: New York 
Status: Alive 
---
## Martino Bresciani
An assassin with the [[Bonanno Family]].  