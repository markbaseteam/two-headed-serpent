---
aliases: 
tags: NPCs
Faction: Bingham
Role: Bartender
Location: Bingham
Status: Alive
---
## Maurice Walsted
The bartender at the Deer Head Saloon.  
