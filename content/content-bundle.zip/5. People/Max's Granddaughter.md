---
aliases: 
tags: NPCs
Faction: Max
Role: Granddaughter
Location: New York
Status: Alive
---
## Max's Granddaughter
[[Max Tannenbaum|Max's]] granddaughter.  