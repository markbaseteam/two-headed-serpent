---
aliases:
tags: NPCs
Faction: Max
Role: Rabbi
Location: New York
Status: Alive
---
## Max's Rabbi
[[Max Tannenbaum|Max's]] rabbi.