---
aliases:
tags: NPCs
Faction: Hugo
Role: Apartment Manager
Location: New York
Status: Alive
---
## Meridith Jones
[[Hugo Gustafsson|Hugo's]] apartment manager.