---
aliases: Warehouse Miles
tags: NPCs
Faction: Amandus
Role: Security Guard
Location: Red Hook Warehouse
Status: Alive
---
## Miles Miller
[[Amandus Winston Steel|Amandus']] friend from the army.  Works at the [[Red Hook warehouse]].