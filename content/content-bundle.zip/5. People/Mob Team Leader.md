---
aliases: 
tags: NPCs
Faction: Inner Night
Role: Operative 
Location: Unknown
Status: Unknown
---
## Mob Team Leader
[[Inner Night]] operative assigned to watch the [[Bonanno Family]].  Turned out to be [[Martino Bresciani]].
