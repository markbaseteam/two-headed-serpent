---
aliases: Mortimer, Lloyd
tags: NPCs
Faction: The First Church
Role: Visitors
Location: Bingham
Status: Alive
---
## Mortimer and Lloyd
A father and son that heard [[Reverend Kornfield]] on the radio and traveled to Bingham.