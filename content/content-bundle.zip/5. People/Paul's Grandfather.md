---
aliases:
tags: NPCs
Faction: Paul
Role: Grandfather
Location: New York
Status: Dead
---
## Paul's Grandfather
[[Paul Schreiber|Paul's]] grandather.
