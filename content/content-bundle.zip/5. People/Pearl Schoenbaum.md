---
aliases: 
tags: NPCs
Faction: The First Church
Role: Skin Shedding Lady
Location: Bingham
Status: Alive
---
## Pearl Schoenbaum
The wife of the blacksmith, [[Bill Schoenbaum]], in Bingham.  Her skin condition was cured by [[Reverend Kornfield]], though it causes her to shed every few days.

Her daughter is [[Susie Schoenbaum]].