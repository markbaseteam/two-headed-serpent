---
aliases: 
tags: NPCs
Faction: The First Church
Role: Housewife
Location: Bingham
Status: Alive
---
## Peggy Shaw
The wife of [[Gregory Shaw]].  People say their baby is cursed by [[Reverend Kornfield]].
