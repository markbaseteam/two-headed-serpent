---
aliases:
tags: NPCs
Faction: Caduceus
Role: Quartermaster
Location: New York
Status: Alive
---
## Phillip Conners
[[Caduceus]] Quartermaster. A bit overweight, balding, sweating, chain smoker.
