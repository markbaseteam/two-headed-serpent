---
aliases: Professor Carole
tags: NPCs
Faction: Unknown 
Role: Professor
Location: Belgian Congo 
Status: Alive
---
## Professor Carole Roux

A professor from Paris in the Belgian Congo researching rumors of dinosaurs.