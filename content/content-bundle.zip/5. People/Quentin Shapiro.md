---
aliases: Shapiro, Snakepiro
tags: NPCs
Faction: Caduceus
Role: Scientist
Location: North Borneo
Status: Dead
---
## Quentin Shapiro
[[Caduceus]] scientist and team handler.