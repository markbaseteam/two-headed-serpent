---
aliases: 
tags: NPCs
Faction: The First Church
Role: Barber
Location: Bingham
Status: Alive
---
## Ralph Kunkel
The co-owner of the barbershop in Bingham with his wife, [[Edith Kunkel]].  He was healed by [[Reverend Kornfield]]. 