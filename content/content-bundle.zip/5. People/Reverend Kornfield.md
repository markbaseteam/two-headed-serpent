---
aliases: Reverend, Kornfield
tags: NPCs
Faction: The First Church
Role: Leader
Location: Bingham
Status: Dead
---
## Reverend Kornfield
Founded [[The First Church]] in Bingham, Oklahoma.  He wandered the desert and died in a mysterious cave.  Came back as a [[Serpent Race|serpent person]]. Wrote of his pilgrimage in his [[Gospel of Yig|bible]].
