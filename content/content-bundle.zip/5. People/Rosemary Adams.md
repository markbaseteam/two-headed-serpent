---
aliases:
tags: NPCs
Faction: The First Church
Role: Hotel Owner
Location: Bingham
Status: Alive
---
## Rosemary Adams
The owner of The Bingham Hotel with her husband, [[Delbert Adams]].  She makes figurines that she sells and are found in all the rooms.