---
aliases: Rose Meadham, Rose
tags: NPCs
Faction: Inner Night
Role: Leader
Location: Unknown
Status: Alive
---
## Sashinal
The head of [[Inner Night]].

![](https://i.imgur.com/nD9eBtz.png)