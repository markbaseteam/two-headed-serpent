---
aliases:
tags: NPCs
Faction: Caduceus
Role: Secetary
Location: New York
Status: Alive
---
## Selma Halberstam
A secretary at [[Caduceus]].  Her flat was tossed.