---
aliases: Sheriff
tags: NPCs
Faction: The First Church
Role: Sheriff
Location: Bingham
Status: Dead
---
## Sheriff Benson
The sheriff in Bingham.  He was a follower of [[Reverend Kornfield]], even calling him Master at one point.  

He died when [[Hugo Gustafsson|Hugo]] took control of the snakes after [[Reverend Kornfield|Kornfield]] was shot.  As a test of faith, Hugo convinced the sheriff to hold a rattlesnake which bit him.  Initially, the poison did not kill him until the "reborn" Kornfield was also killed.