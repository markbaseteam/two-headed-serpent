---
aliases: Amandus' dead girlfriend
tags: NPCs
Faction: Amandus
Role: Dead Girlfriend
Location: Unknown
Status: Dead
---
## Stephanie
[[Amandus Winston Steel|Amandus']] dead girlfriend.  He lost a lock of her hair, but someone mailed it back to him in a copy of [[Cultes des Goules]].