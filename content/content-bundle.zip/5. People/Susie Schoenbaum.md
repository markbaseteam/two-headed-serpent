---
aliases: 
tags: NPCs
Faction: Bingham
Role: Mad Youngster
Location: Bingham
Status: Alive
---
## Susie Schoenbaum
The daughter of [[Bill Schoenbaum|Bill]] and [[Pearl Schoenbaum]] in Bingham.  She tried to burn down the church with [[Gregory Shaw]].