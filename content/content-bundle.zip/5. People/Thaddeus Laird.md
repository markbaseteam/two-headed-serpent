---
aliases: Thaddeus, Joseph's brother
tags: NPCs
Faction: Joseph
Role: Brother
Location: Belgian Congo
Status: Dead
---
## Thaddeus Laird
The younger brother of [[Joseph Laird]].  A member of [[Caduceus]].  Joseph was told he was just a Tier 1 member.  He died of the sleeping sickness in the Belgian Congo and his remains were not recovered.