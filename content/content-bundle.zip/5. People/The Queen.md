---
aliases: Snake lady, snake lady, Snake Queen, Snake Queen Lady, Serpent Queen, Tyranissh, Tyranissh's, the Dreamer, The Dreamer
tags: NPCs
Faction: Serpent People
Role: Leader
Location: Unknown
Status: Alive
---
## The Queen
An ancient queen of the [[Serpent Race|Serpent people]].  Captured by [[Caduceus]] but was annoyed with their questioned.  Claimed [[Yig]] was just a person and not that good.

She escaped through a magical portal.

She says she worships [[Ghatanothoa]].