---
aliases: 
tags: NPCs
Faction: Unknown
Role: Museum Curator 
Location: Calcutta
Status: Alive
---
## Vatsala Kumtekar
Head Curator of the India Museum in Calcutta.