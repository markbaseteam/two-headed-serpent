---
aliases: Artiro
tags: NPCs
Faction: Inner Night 
Role: Demolitions Specialist
Location: New York 
Status: 
---
## Vernere Ardiro

A safecracker and explosives expert who usually works alone.  He takes orders, but usually thinks his judgement is better than others.  He is scared of pain.

He is either working with [[Inner Night]], or is being tricked by them to try and blow up the [[Caduceus Building]].