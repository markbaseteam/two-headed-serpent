---
tags: Book 
---
## Book of Eibon 
Has the following spells.
- Call/Dismiss Azathoth
- Contact Formless Spawn of Zhothaqquah
- Contact Kthulhut 
- Contact Yok Zothoth 
- Contact Zhothaauah 
- Create Gate 
- Create Mist of R'lyeh
- Enchant Knife
- Green Decay
- Wither Limb
