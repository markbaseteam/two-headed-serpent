---
aliases: The Crown, the Crown
tags: Item
Summary: Was missing from the Queen's tomb.
---
## Cobra Crown
Not in the tomb.