---
tags: Item
Summary: A mysterious book mailed to Amandus.
---
## Cultes des Goules
A mysterious book that mailed to [[Amandus Winston Steel|Amandus]] along with a lock of his [[Stephanie|dead girlfriend's]] hair.