---
tags: Item
Summary: A chemical compound used in insect repellent.
---
## Dimethyl phthalate
A chemical compound used in insect repellent.  Frequently shipped to the [[Red Hook warehouse]].