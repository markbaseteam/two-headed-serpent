---
tags: Ritual
Summary: Allows the Queen to communicate in dreams.
---
## Dreamlink
A process where [[The Queen]] can communicate with people in their dreams.  [[Max Tannenbaum|Max]] and [[Amandus Winston Steel|Amandus]] have accepted the link.  [[Hugo Gustafsson|Hugo]] did as well as the Queen escaped.