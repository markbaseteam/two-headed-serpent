---
tags: Book
---
## Extracts from the R'lyeh Text
Has English notes from [[Caduceus]] researchers.

Contains the following spells.
- Contact [[Ghatanothoa]] 
- Contact Deep Ones 
- Contact Lloigor 
- Curse of the Stone 
- [[Grasp of Cthulhu]] 
- Wave of Oblivion.
