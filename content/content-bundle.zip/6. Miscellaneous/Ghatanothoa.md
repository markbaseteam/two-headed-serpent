---
tags: Deity
Summary: The Queen considers this the true faith.
---
## Ghatanothoa
The Dark God, worshipped by [[The Queen]].