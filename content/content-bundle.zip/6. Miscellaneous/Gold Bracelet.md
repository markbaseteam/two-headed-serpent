---
aliases: snake bracelet, flame bracelet
tags: Item
Summary: A bracelet with the ability to shoot flames.
---
## Gold Bracelet
A bracelet with the ability to shoot flames.  Found in Bolivia and modified by [[Paul Schreiber|Paul]].