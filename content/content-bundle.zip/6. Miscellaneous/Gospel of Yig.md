---
tags: Item
Summary: Reverend Kornfield's former Bible that converted to the worship of Yig.
---
## Gospel of Yig
A large, leather bound tome, which was originally a standard Bible.  The margins contain many handwritten notes and drawings.  Some passages have been amended, some crossed out, and replaced with new ones.

- Sanity Loss 1d6
- Cthulhu Mythos (Initial Reading): +2 %
- Cthulhu Mythos (Full Study): +4%
- Mythos Rating: 18
- Study: 7 days
- Spells: maybe

Anyone performing an initial reading of the gospel also gains +2% in [[Naacal]].

![](https://i.imgur.com/MPASFGW.jpg)