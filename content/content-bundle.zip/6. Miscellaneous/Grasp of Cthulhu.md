---
tags: Spell
---
## Grasp of Cthulhu 
Immobilizes the target.