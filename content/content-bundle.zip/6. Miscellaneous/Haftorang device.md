---
tags: Item
Summary: Doomsday device in North Borneo.
---
## Haftorang device
A doomsday device to be used to prevent the spread of the [[Yellow Death]].  

[[Paul Schreiber|Paul]] knows:                           

- chest (20 x 20 x 30 inches). The box lies on its side, with one of the four larger faces being comprised of a two-part lid, attached by brass hinges on the longer sides. A rotating brass disc, inscribed with a four-pointed star, holds the lid in place.
- The four faces around the outside of the box are inscribed with patterns of stars, which a successful Astronomy roll reveals to be the constellations of Leo (northern face), Taurus (eastern face), Piscis Austrinus (southern face), and Scorpius (western face). On each face, silver strips inlaid into the wood form the lines between the stars. The majority of the stars are marked with citrine (yellow quartz), except for Regulus (Leo), Aldebaran (Taurus), Fomalhaut (Piscis Austrinus) and Antares (Scorpius), which are all marked by rubies. The aforementioned Astronomy roll also reveals that these are the “Royal Stars”—according to ancient Persian wisdom, the guardians of the sky, named Venant, Tascheter, Haftorang, and Satevi, were believed to hold both the power of good and evil.
- Across both halves of the lid, two fishes are carved, inlaid with gold. The mouths of both fishes are open and pointed towards one another, with the brass disc that keeps the box closed between them (corresponding to the position of Fomalhaut in Piscis Austrinus).
- The brass disc must be turned 360 degrees to open the lid. The interior of the box is filled with a complex series of rotating hoops, discs, wheels, and gears. All are made of brass and inscribed with astrological sigils that chart various paths through the celestial sphere. The entire mechanism resembles a strange armillary sphere, with a large tetrahedron made from a single ruby, about the size of a clenched fist, at its heart.
- A series of six dials, three at each end of the interior of the chest, are marked with the numbers 1 through 10 in Persian. Once one is turned, they all begin to click and turn, implying it might be a mechanism of some fashion to measure the passage of time.

Basically, it will open into the heart of the star - likely 5 mile radius.