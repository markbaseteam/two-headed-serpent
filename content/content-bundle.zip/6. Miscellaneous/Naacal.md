---
tags: Language
Summary: An ancient language.
---
## Naacal
An ancient language.