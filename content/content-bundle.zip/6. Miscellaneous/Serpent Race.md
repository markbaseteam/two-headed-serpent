---
aliases: Serpent race, Serpent people, Serpent People, serpent people, serpent person, snake person, serpent people race, Snake people, serpent folk
tags: Race
Summary: An ancient race that walked the lands long before the rise of humanity.
---
## Serpent Race
According to [[Caduceus]]:

It appears that the serpent people are native to Earth, having ruled empires that have now faded into history, and walked lands long before the rise of humanity. A religious schism occurred many millennia ago that split the race in two. One side worships an entity called [[Yig]], the Father of Serpents (potentially the progenitor of the race). The other worships an entity known as [[Tsathoggua]], an evil toad-like monstrosity that revels in vile acts and atrocities. 

## NPCs
- [[The Queen]]
- [[Sashinal]]
- [[Joshua Meadham]] 

