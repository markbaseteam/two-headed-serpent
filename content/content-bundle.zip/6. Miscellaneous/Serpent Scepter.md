---
tags: Item
Summary: Allows the control of snakes.
---
## Serpent Sceptre
Ornate scepter with a pearl the size of a fist on the end. Serpentine carved.