---
aliases: Transport Spheres
tags: Item
summary: 
---
# Transport Sphere
How the [[Serpent Race|serpent people]] plan to leave the Iceland location.  First seen in Bolivia.