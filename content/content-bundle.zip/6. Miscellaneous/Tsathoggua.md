---
tags: Deity
Summary: Frog God
---
## Tsathoggua
The Frog God.  The [[Serpent Race]] split, with one side worshipping [[Yig]] and the other side worshipping Tsathoggua.