---
tags: Item
Summary: Can detect if disease is natural or Yellow Death.
---
## Viral Analyzer
Can detect if disease is natural or [[Yellow Death]].