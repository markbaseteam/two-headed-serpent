---
tags: Disease
Summary: A serpent person biological weapon.
---
## Yellow Death
A [[Serpent Race|serpent person]] biological weapon designed to depopulate areas of human habitation. Its use leads [[Caduceus]] to suspect the involvement of the [[Inner Night]].

Yellow Death spreads rapidly but has a key flaw, that it burns out within a month. [[Caduceus]] is especially concerned that [[Inner Night]] may have figured out how to genetically modify this strain to extend the weapon indefinitely.