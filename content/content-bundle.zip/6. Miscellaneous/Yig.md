---
aliases: Father of Serpents, Father of Snakes
tags: Deity
Summary: The Father of Serpents
---
## Yig
The Father of Serpents.  The [[Serpent Race]] split, with one side worshipping Yig and the other side worshipping [[Tsathoggua]].