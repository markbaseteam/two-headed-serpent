---
tags: Book 
---
## Zanthu Tablets
Has worship instructions for [[Ghatanothoa]], Cthulhu, Shub-Niggurath.
