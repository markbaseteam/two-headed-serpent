---
tags: Notes
---
## Bolivia Briefing
[[Caduceus]] Mission Briefing  
Date: 12th March 1933  
To: [[Dr. Arturo Ursini]]

BRIEFING FOR BOLIVIA MISSION

Proceed to aid camp (see map) Present [[Dr. Gomez]] (in charge of the aid camp) with the enclosed letter .

You should first make your way to t site of the recent confrontation. The site is approximately two miles west of the aid camp. on the far side of the river. Beware of possible level 3 threat In the vicinity: Our intelligence on the threat is regrettably limited. We believe the threat is a temple guardian of some kind. 

Your mission is to enter the temple and retrieve the mummy for immediate return to [[Caduceus]] HQ in New York. Any accompanying artifacts should likewise be recovered and brought home. 

Your team of specialists is very able. but new to the job. As always we find it best to initiate and test newcomers In the field. Brief them as and when you see fit. We will expect a report on the individual team members on your return. 

You have proven over and again that you can keep your head when those around you are losing theirs. We have every confidence in your abilities.  

Regards,  

[[Quentin Shapiro|Shapiro]]

![](https://i.imgur.com/kAAArFs.jpg)