---
tags: Notes
---
12th March 1933  

Dear [[Dr. Gomez]]

We hope all is well at the camp. This letter should be handed to you by [[Dr. Arturo Ursini]], a trusted member of our organization. He and his team have important work to conduct in the vicinity of your camp.  Please extend to him and his teem your support arid hospitality. I trust the additional staff and supplies that he brings will prove useful.

Yours sincerely,

[[Quentin Shapiro|Shapiro]]

![](https://i.imgur.com/K8nauFp.jpg)