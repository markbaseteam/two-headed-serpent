---
tags: Notes
---
## Caduceus Briefing
### Tier One Briefing
The text outlines the history of the [[Caduceus|Caduceus Foundation]]. In 1912, [[Joshua Meadham]] sold the pharmaceutical empire he had built up over the previous 30 years. With the proceeds, he founded the Caduceus Foundation. Various newspaper articles follow, each detailing the help Caduceus has brought to people across the globe following epidemics, natural disasters, and wars. 

### Tier Two Briefing
The text outlines information that the [[Caduceus|Caduceus Foundation]] has been able to learn about the [[Serpent Race|serpent people race]]. It appears that the serpent people are native to Earth, having ruled empires that have now faded into history, arid walked lands long before the rise of humanity. A religious schism occurred many millennia ago that split the race in two. One side worships an entity called [[Yig]], the Father of Serpents (potentially the progenitor of the race). The other worships an entity known as [[Tsathoggua]], an evil toad-like monstrosity that revels in vile acts and atrocities. This latter faction refers to themselves as ‘[[Inner Night|The Inner Night]].” 

[[Caduceus]] has found, in their experience, the worshipers of [[Yig]] are content to hide from humanity, deep below the ground in subterranean cities. They know that to pick a fight with humanity could spell annihilation, despite their vastly superior technology. Conversely, the evidence that Caduceus has gathered makes the organization believe that [[Inner Night|the Inner Night]] (who were responsible for attacking [[Joshua Meadham]]) is working toward a plan that will spell disaster for the human race. The details of this plan are not yet known but it is imperative that it be discovered soon. 

[[Inner Night|The Inner Night]] faction is organizing and coordinating its efforts across the globe. There might not be much time left. 

*Some of the sources referred to in this pack are written in [[Naacal]] (there are translation notes supplied). *

*Anyone studying these for a day can gain + 10 percentiles in Other Language ([[Naacal]]). *

#### Tier Two Briefing Pack  
- Sanity Loss: 1D4 
- Cthulhu Mythos: +5 percentiles  
- Mythos Rating: 10  
- Study: 2 hours  
- Spells: none

![](https://i.imgur.com/nU6erYq.png)