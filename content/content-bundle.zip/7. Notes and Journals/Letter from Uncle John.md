---
tags: Notes
---
## Letter from Uncle John
My good friend [[Joseph Laird|Joseph]],

We are ready to pull the trigger tonight on the [[Red Hook warehouse|business acquisition]] we discussed.  We will go forward with or without your and your team, but would be to have your expertise to avoid unnecessary losses to the [[Caduceus|company]] we are acquiring - otherwise we will just let the chips fall where they may, but this has become a matter of some urgency.  We'll be at the [[Green Garden Cafe]] at 8pm tonight if you would to meet and discuss.

Your friend,

[[Giovonni Bonventre|John]]

![](https://i.imgur.com/suCMVxC.png)