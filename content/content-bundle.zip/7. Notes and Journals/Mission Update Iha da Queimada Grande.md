---
tags: Notes 
---
## Mission Update Iha da Queimada Grande
[[Dr. Sergio Cerqueira]]
Station Chief
[[Caduceus]] Field Office  
Santos  
Brazil  

February 27th, 1933  

Mission Update: Ilha da Queimada Grande  

The research provided by [[Dr. Victor Gomes Goncalves|Dr. Goncalves]] has proved correct. After following his most recent suggestions, the Ilha da Queimada Grande field team succeeded in stabilizing the portal. Unfortunately they are unable to confirm that the exit point is located on [[Mu]] and have had to close the portal for the foreseeable future.  

What our research failed to indicate is that either the portal, or possibly the exit point, is guarded. Shortly after opening the portal, the field team was assaulted by a large, unidentified reptilian creature. This creature proved not only violent but also capable of some act of sorcery that resulted in the deaths of all but one member of the field team. The bodies were torn apart and, in most cases, were rendered unidentifiable.

We have since replenished the field team and wish to proceed with caution. Are you able to offer any advice on this entity and how it may be neutralized?  

[[Dr. Sergio Cerqueira|Dr. Cerqueira]]

*Hand Written by [[Dr. Victor Gomes Goncalves|Goncalves]]*

This sounds like the [[Old Enemy]] still bearing a grudge about your ancestor's harnessing of their god.  We had hoped they had abandoned [[Yaddith-Gho]] in the millennia since [[Mu|Mu's]] departure, but apparently they are tenacious.

There may be enough of the reptile in their nature that the [[Cobra Crown]] may provide a means to control or neutralize them.  I advise stepping up search efforts in Calcutta, as current research supports our conjecture that it is the most likely location.

[[Dr. Victor Gomes Goncalves|Goncalves]]