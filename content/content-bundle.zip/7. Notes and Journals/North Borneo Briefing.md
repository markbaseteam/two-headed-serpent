---
tags: Notes
---
## North Borneo Briefing
- The North Borneo Chartered Company has contacted [[Caduceus]] for assistance.  
- The first symptoms of what is believed to be infectious hepatitis appeared on March 16th. The first deaths occurred on March 18th.  
- The company believes the outbreak to be an unusual form of infectious hepatitis; one that is acting at an accelerated rate. 
- Subjects with the disease normally display first symptoms two to six weeks after infection. Such symptoms normally last up to eight weeks, which can result in acute liver failure and death. In the recent outbreak, subjects have died just two days after displaying symptoms in North Borneo. 
- From the information [[Caduceus]] has been able to obtain, it is believed that the outbreak could be the [[Yellow Death]], a [[Serpent Race|serpent person]] biological weapon designed to depopulate areas of human habitation. Thus, Caduceus suspects the involvement of the [[Inner Night]].
	- [[Yellow Death]] spreads rapidly but has a key flaw, that it burns out within a month. [[Caduceus]] is especially concerned that [[Inner Night]] may have figured out how to genetically modify this strain to extend the weapon indefinitely.
- The team’s mission is to enter the quarantine site, allowing [[Caduceus]] scientists to determine whether or not this is the [[Yellow Death]] at work. The team will then determine whether there is an [[Inner Night]] presence, find out what their objective is, and stop them. 

[[Quentin Shapiro|Shapiro]] will join the team as their scientific advisor, performing the tests necessary with a [[Viral Analyzer]] to identify the [[Yellow Death]]. An array of chemicals, compounds, and drugs are at their disposal to craft an antidote. 

![](https://i.imgur.com/K2aftl2.jpg)