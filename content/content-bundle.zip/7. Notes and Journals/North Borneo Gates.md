---
tags: Map
---
## North Borneo Gates
![](https://i.imgur.com/AKcO1Fg.jpg)