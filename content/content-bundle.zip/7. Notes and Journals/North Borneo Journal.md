---
tags: Journal
---
## North Borneo Journal
February 27, 1933 - We have sensed a previously unknown field of [[Serpent Race|serpent person]] technology in Southeast Asia.  [[Sashinal]] has sent me to investigate.

February 28, 1933 - Traced the [[Serpent Race|serpent person]] field to Mount Kinabalu.  The veil between here and the [[Dreamlands]] appears to have been breached in much of the area the serpent person technology signs are strongest.

March 3rd, 1933 - I have found the exposed remains of an old serpent person facility in Mount Kinabalu.  A gate inside appears to be operational, though very under powered - perhaps our ancestors found a way to power the gate with the veil.  That it can cross the planes right now is promising - perhaps if it were fully powered it could reach [[Mu]]. I'm unsure of whether the rest of the facility is functional.

March 13, 1933 - Still no luck increasing power to the gate - the rest of the facility appears to be destroyed and I have not been able to restore functionality to the screens.  Power appears to be running out in the facility and the gate grows weaker.  Still not sure what originally caused it to turn on.

March 13, 1933 - My new theory is that the gate is powered by deaths in the local area.  I'ved a [[Yellow Death|contaminant]] to the water - something [[Sashinal]] was able to develop during her time as Rose Meadham - to infect the local population and hopefully power the gate to test the theory.

March 30, 1933 - The deaths from the [[Yellow Death|plague]] have clearly increased power to the gate but not nearly enough to fully power it.  Our spies in [[Caduceus]] indicate a team is coming with a [[Haftorang device]] - perhaps this will be sufficient to power the gate.  I am still unable to activate the screens.

April 12, 1933 - The [[Caduceus]] team has arrived with the [[Haftorang device]]! With the grace of [[Tsathoggua]], soon we shall have an operational gate and reach [[Mu]].

![](https://i.imgur.com/aXe27gZ.jpg)