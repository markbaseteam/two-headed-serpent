---
tags: Map
---
## North Borneo Pangea
![](https://i.imgur.com/f5MUlUE.jpg)