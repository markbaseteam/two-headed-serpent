---
tags: Notes
---
## Oklahoma Briefing
### Mission Briefing: Friday April 28, 1933  
#### Assignment  
- Investigate what is going on with a light touch for now. Confirm whether this is indeed a cult of [[Yig]] or something else and whether [[Serpent Race|serpent people]] — including the [[Inner Night]] — could be involved. It would be highly unusual for a true cult of Yig to appear spontaneously amongst humans.  
- Report daily to [[Joshua Meadham|Meadham]] about progress — a radio transmitter has  been provided.  

#### Mission Background  
- A cult appearing to be worshiping [[Yig]] has come to the attention of [[Caduceus]]  
- Weekly broadcasts from Radio KFOC in Oklahoma City  
- [[Reverend Kornfield|Reverend Kornfield's]] sermons appear to have a secondary track of [[Naacal]] embedded in them and to create a compulsion in some listeners to visit Bingham, Oklahoma  
- Unsure how long ago the broadcasts started but appears to be fairly recent  

#### Bingharn. Oklahoma Background  
- Around fifty miles Southwest of Oklahoma City with a rail line.  
- Ostensibly a town of 749 residents. specializing in cotton and peanut production, but the region has been plagued with poor growing conditions recently including droughts and hail storms.  
- Humid and hot: (60sF at night. 80sF in the day  
- Broadcasts are from [[Reverend Kornfield]] at [[The First Church]]. Phone book lists First Church of Christ the Redeemer at 5th and Liberty.  
- Town has a Railway Station and a combined Telegraph-Post Office  
- Rooms can be let at The Bingham Hotel or the Deer Head Saloon  
- Most other key buildings can be found along Main Street. including the Sheriff’s Office and the local newspaper. the *Bingham Journal*.

![](https://i.imgur.com/EZif0MG.jpg)