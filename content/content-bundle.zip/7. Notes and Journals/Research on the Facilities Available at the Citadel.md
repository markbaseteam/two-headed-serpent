---
tags: Notes
---

## Research on the Facilities Available at the Citadel 
[[Dr. Victor Gomes Goncalves|Dr. Victor Goncalves]] 
[[Caduceus]] Chief Researcher
[[Caduceus Building|Meadham Building]] 
New York City 

April 10th, 1933 

Research on the Facilities Available at [[the Citadel]]

Before I present my report, please let me apologize for the paucity of the detail. It has been unexpectedly difficult to find written records about [[the Citadel]]. Much of the information we were able to collate comes from [[The Queen|Tyranissh]], and I fear that her heretical beliefs and hostility to our organization make her an untrustworthy source. 

Assuming [[the Citadel]] has survived the past ten thousand years, we may be able to expect the following. 

- The amount of energy available to [[the Citadel]] and its systems is essentially unlimited. Ancient writings refer to your ancestors harnessing the power of a god. Given the location of [[Yaddith-Gho]] and [[The Queen|Tyranissh's]]  hostile reaction when pressed for details, we can assume the god in question is [[Ghatanothoa]].
- The proximity to [[Ghatanothoa]] presents potential danger. Multiple sources give dire warnings about the "curse" placed upon those who look upon the god. The recent incident at the [[Joshua Meadham|Meadham Estate]] would Indicate that this is not merely superstition. 
- [[The Queen|Tyranissh]] confirms that there are large-scale manufacturing facilities available at [[the Citadel]]. It appears that we will be able to create any biological agents you require. There are also facilities for the assembly of biomechanical entities. and Tyranissh believes that they would allow the mass creation of insects. 
- There are mechanisms in place for the manufacture and control of transport spheres. We believe these may be connected to the operation of the so-called "[[Doomsday Device]]."
- There are automated defense systems protecting [[the Citadel]], although these may no longer be active. [[The Queen|Tyranissh]] last saw [[the Citadel]] long before the final fate of [[Mu]] and is unable to confirm the reports of newer stronger defenses. 

At the risk of being too forthright, may I please request that you share the rest of your plans for the use of these facilities with me? I can offer much more informed advice if I know what resources you may require. 

[[Dr. Victor Gomes Goncalves|Goncalves]] 