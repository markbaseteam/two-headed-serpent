---
tags: Notes 
---
## Summary of Research on the Cobra Crown
[[Dr. Victor Gomes Goncalves|Dr. Victor Goncalves]]
[[Caduceus]] Chief Researcher
[[Caduceus Building|Meadham Building]] 
New York City

March 6th, 1933  

Summary of Research on the [[Cobra Crown]] 

Although we have yet to determine if there is any truth to the rumors that the [[Cobra Crown]] has resurfaced in Calcutta, my research team has managed to find many details about the Crown and its power in our library.  The key facts that we have corroborated from multiple sources can be summarized as follows:

- The [[Cobra Crown]] was created by the [[Serpent Race|serpent people]] before recorded history. It has been referenced in various myths and historical texts as allowing its wearer to command snakes and reptiles. There is no indication that this extends to control over serpent people. 
- Putting on [[Cobra Crown|the Crown]] involves some form of trial or ordeal. Only those found worthy are then granted its power.
- The [[Cobra Crown]] is said to be paired with the [[Serpent Scepter]]. Both are reputed to be located in the Temple of the Dreamer in Bolivia. We will be able to confirm this when our field team recovers [[The Queen|the Dreamer]].
-  Given the sightings of [[Cobra Crown|the Crown]] across Asia over the past two thousand years, it seems likely that it has long since been stolen from the temple. There have been no mentions of the [[Serpent Scepter]] being seen with it.  

Given your personal interest in the [[Cobra Crown]], I have taken the liberty of putting one of the company's aircraft on standby to take you to Calcutta as soon as we confirm that this is not another false lead. I have also reserved a suite at the Great Eastern Hotel for the next two months to ensure its availability at short notice. 

Our informants in Calcutta have warned us that the [[Inner Night]] is active in the area and that [[Sashinal|your daughter]] has also taken an interest in gaining control of [[Cobra Crown|the Crown]]. I suggest you approach with caution. 

[[Dr. Victor Gomes Goncalves|Goncalves]] 
