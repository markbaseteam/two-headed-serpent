---
tags: Notes
---
## Temple Security Letter
[[Francesca De Luca|Chief of Security]]
[[Caduceus Building|Meadham Building]]
New York City  

March 3rd, 1933  

Re: Break-in st the Connecticut Estate, February 24th  

My men have completed their investigation of last month’s break-In at the [[Joshua Meadham|Meadham]] Estate. Their findings are:  

- There is no indication of this being an inside job or of [[Caduceus]] staff providing assistance to burglars. 
- The dead guards were killed by sorcerous means. 
- Nothing of value was taken, but every building had been searched extensively. 
- The desecration of the temple suggests that the intruders were enemies of the [[Yig|Father of Snakes]]. 
- The lack of dead snakes in the temple indicates that the Intruders had nothing to fear from snake venom. 

All of these factors indicate that the [[Inner Night]] are involved. Given the public nature of the [[Joshua Meadham|Meadham]] Estate, it will be difficult to defend should they return. No materials relating to [[Caduceus]] operations should be stored at the Estate for the immediate future. Any artifacts or religious texts should be removed to the storeroom on the 7th floor of the [[Caduceus Building|Meadham Building]], and any scientific materials and specimens should be secured in the laboratory in the lower basement. All sensitive documents should be kept in Mr. Meadham’s personal safe. 

Given that we will be unable to relocate the temple, we will retain a presence at the Connecticut Estate. I recommend that we increase the security presence at the estate by three men per shift and double the patrol frequency. We shall have to use human guards due to lack of essential resources, and I will vet them personally. 

Replacements for the trained guard dogs killed by the Intruders are also essential. Can I please request that we do not attempt to use those lizard hybrids we experimented with last year? Their baying attracted attention from neighbors, and Jenkins needed to have his arm amputated after the incident

![](https://i.imgur.com/IRdiuzd.jpg)