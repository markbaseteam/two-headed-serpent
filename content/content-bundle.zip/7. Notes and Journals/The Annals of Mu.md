---
tags: Notes
---
## The Annals of Mu
These fragile scrolls are written in [[Naacal]] and tell the history of [[Mu]] and describe the rise of the usurper race of humanity in [[Valusia]]. Opinions about humanity among the [[Serpent Race|serpent people]] are divided. One faction of serpent people saw the future of their race in coexistence with humans and went so far as to mix their genetic material with humanity. They constructed a temple, over a dead Volcano and drew upon its arcane power to fuel their engines of transformation. The rest of the serpent people saw the human race as a scourge and something to be eradicated, fearing that interbreeding would contaminate the pure serpent person bloodline. The resulting conflict led to the growth of extremist factions and a civil war. 

The scrolls also describe an assault on the citadel in [[Mu]] by an alien race. This attack somehow resulted in the shattering of reality, separating Mu from the rest of Earth. any of the [[Serpent Race|serpent people]] were left unable to return home to Mu, destined to walk în the world of men. The final passages ‘ speak of the Chosen One: a serpent person whose destiny is to unite the serpent people and lead them home to glorious Mu. 

### The Annals of Mu  
- Language: [[Naacal]]
- Cthulhu Mythos (Initial Reading): +1%  
- Cthulhu Mythos (Full Study): +3%
- Mythos Ratìng: 12
- Reading Time: 1 week
- Sanity Cost: 1 Dd

![](https://i.imgur.com/BgIhPT9.jpg)