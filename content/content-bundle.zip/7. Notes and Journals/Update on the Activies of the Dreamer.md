---
tags: Notes
---
## Update on the Activies of the Dreamer
[[Dr. Victor Gomes Goncalves|Dr. Victor Goncalves]]
[[Caduceus]] Chief Researcher
[[Caduceus Building|Meadham Building]]
New York City  

May 3rd, 1933  

Update on the Activities of the Dreamer  

After debriefing employees and agents who have interacted with [[The Queen|Tyranissh]] (often referred to as The Dreamer by said individuals), we believe that we have established some troubling details.

- [[The Queen|Tyranissh's]] allegiance lies not with [[Yig]] or [[Tsathoggua]] but with [[Ghatanothoa|Ghatanothoa]]. This makes her an unknown factor in the current conflict.
- On learning more about the current schism between our faith and the worshippers of the abomination, she has become openly hostile to both of us. She believes that your people have "lost their way" and that it is her role to "fix the problems you have created."
- She has taken an unsettling degree of interest in our experiments with hybridization technology. In fact, if her claims are to be believed, she may even have invented this technology during her days on [[Mu]].
- In conversation with some of her more trusted confidents, [[The Queen|Tyranissh]] has expressed an interest in returning to [[Mu]], and [[the Citadel]] in particular. In combination with her interest in hybridization technology, this makes me fear that she has plans to make use of the facilities there to effect change on a massive scale. 
- She has also developed an obsession with the location of the [[Cobra Crown]]. It is possible that she has the same plans for it as we have. 

My recommendation is that [[The Queen|Tyranissh]] be treated as hostile.  She is too useful a link to the past to eliminate completely, but we cannot in any way rely on her cooperation. My fear is that she will become as grave a threat to our plans as [[Sashinal]]. 

[[Dr. Victor Gomes Goncalves|Goncalves]]