---
tags: Notes
---
## Update on the Activies of the Inner Night
[[Dr. Victor Gomes Goncalves|Dr. Victor Goncalves]]
[[Caduceus]] Chief Researcher
[[Caduceus Building|Meadham Building]] 
New York City

April 30th, 1933  

Update om the Activities of the [[Inner Night]]

Our informants within the [[Inner Night]] have recently provided the last pieces of information I needed to piece together the scope of their current activities. I regret to inform you that the situation is even worse then we had believed. 

[[Sashinal]]  appears to be mirroring our effort to reach [[Mu]]. She nay also be monitoring our activities. ready to take the Gate for herself once we have made it safe. At minimum, I recommend that we proceed with the extreme countermeasure we discussed deploying around the Ilha da Queimade Grande. This should at least stop any unauthorized vessels from approaching the island. 

Once on [[Mu]], it appears that the [[Inner Night]] plan to return the island back to our plane of existence and activate the volcano network that your ancestors constructed in [[the Citadel]], which some of our more excitable researchers refer to as the "[[Doomsday Device]]" .

If the [[Inner Night]] were to succeed, our current estimate is that the surface of the Earth would become uninhabitable for many hundreds of years. This would affect not only my race but yours as well. The [[Inner Night]] appears to have access to subterranean facilities that will allow them to survive while the rest of us perish. 

Under no circumstances must we allow [[Sashinal]] or any other members of the [[Inner Night]] to reach [[the Citadel]]. If they have other unknown means to do so before we can make our own way to [[Mu]], not only are our own plans imperiled - so is our very existence. 

[[Dr. Victor Gomes Goncalves|Goncalves]] 