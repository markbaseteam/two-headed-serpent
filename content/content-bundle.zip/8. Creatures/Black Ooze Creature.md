---
name: Black Ooze Creature
aliases: 
tags: Creature
---
# Black Ooze Creature
Things made of black ooze found in the old temple in Bolivia.

