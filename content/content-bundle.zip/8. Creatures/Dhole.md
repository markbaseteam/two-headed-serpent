---
aliases: 
tags: Creature
---
# Dhole
Huge, slimy worm-like creatures, at least several hundred feet long.  Can spit green slime.





