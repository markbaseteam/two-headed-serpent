---
aliases: 
tags: Creature
---
# Gug
Three toed monster.


