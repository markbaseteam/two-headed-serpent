---
aliases: 
tags: Creature
---
# Leng Spider
Very intelligent and very poisonous spider creature from the [[Dreamlands]].  Its webs are like steel cables.


