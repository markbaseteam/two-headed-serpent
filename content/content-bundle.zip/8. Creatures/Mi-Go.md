---
aliases: 
tags: Creature
---
# Mi-Go
The creatures that originally built the Iceland facility the [[Serpent Race|Serpent people]] took over.  They were put into the braincases.  [[Paul Schreiber|Paul]] had a bout of madness where he had the memories of a Mi-Go engineer.



