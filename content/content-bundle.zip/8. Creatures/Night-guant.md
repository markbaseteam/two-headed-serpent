---
aliases: Night-guants
tags: Creature
---
# Night-guants

Flying creatures having smooth whale-like skin, long slender humanoid bodies, curving horns, leather bat-like wings, and a blank expanse of flesh where one would expect a face to be.

