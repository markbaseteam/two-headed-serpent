---
home: true
---
# Two-Headed Serpent
A Pulp Cthulhu campaign by Amanda.

[Google Doc Notes](https://docs.google.com/document/d/1hA-FZmemPdXmeldkp6me_h6w2VVWW1QWsxiUV8zSqLY/edit#)

## PCs
- [[Amandus Winston Steel]]
- [[Hugo Gustafsson]]
- [[Joseph Laird]]
- [[Paul Schreiber]]
- [[Clara Boyce]]
- [[Max Tannenbaum]]